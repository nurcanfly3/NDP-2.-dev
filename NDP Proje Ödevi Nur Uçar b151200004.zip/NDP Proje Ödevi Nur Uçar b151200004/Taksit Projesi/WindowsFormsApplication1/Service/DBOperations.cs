﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaksitApp.Model;

namespace TaksitApp.Controller
{
    //Bu class içerisinde tüm DB işlemleri yapılmaktadır
    //Statik olarak tanımlandığı için metodları çağırırken instance oluşturmaya gerek yoktur
    //Yapılan db işmeleri kısaca ilgili controller'lar içinde açıklanmıştır
    public static class DBOperations
    {
        static String cs = ConfigurationManager.ConnectionStrings["TaksitDBConnectionString"].ConnectionString.ToString();
        

        public static Customer[] GetAllCustomers()
        {
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand command = new SqlCommand("SELECT * FROM Customers", conn);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<Customer> customerList = new List<Customer>();
            if (!reader.HasRows)
            {
                return null;
            }
            while (reader.Read())
            {
                customerList.Add(new Customer(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetInt32(3), reader.GetString(4)));
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Dispose();
            }
            return customerList.ToArray();
        }

        public static bool updateCustomer(Customer customer)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                
                SqlCommand command = new SqlCommand("UPDATE Customers SET Name = @cname, Surname=@csurname, IdentityNumber=@cidnumber, Address=@caddress Where id = @cId", conn);             
                SqlParameter cname = new SqlParameter("@cname", SqlDbType.VarChar);
                SqlParameter csurname = new SqlParameter("@csurname", SqlDbType.VarChar);
                SqlParameter cidnumber = new SqlParameter("@cidnumber", SqlDbType.Int);
                SqlParameter caddress = new SqlParameter("@caddress", SqlDbType.VarChar);
                SqlParameter cid = new SqlParameter("@cId", SqlDbType.Int);
                cname.Value = customer.Name;
                csurname.Value = customer.SurName;
                cidnumber.Value = customer.IdentityNumber;
                caddress.Value = customer.Address;
                cid.Value = customer.Id;
                
                command.Parameters.Add(cname);
                command.Parameters.Add(csurname);
                command.Parameters.Add(cidnumber);
                command.Parameters.Add(caddress);
                command.Parameters.Add(cid);
                command.Connection.Open();
                command.ExecuteNonQuery();
                return true;
            } catch (Exception e)
            {
                
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static bool insertCustomer(Customer customer)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO Customers (Name, Surname, IdentityNumber, Address)  VALUES (@cname, @csurname, @cidnumber, @caddress)", conn);
                command.Connection.Open();
               // SqlParameter cid = new SqlParameter("@cId", SqlDbType.Int);
                SqlParameter cname = new SqlParameter("@cname", SqlDbType.VarChar);
                SqlParameter csurname = new SqlParameter("@csurname", SqlDbType.VarChar);
                SqlParameter cidnumber = new SqlParameter("@cidnumber", SqlDbType.Int);
                SqlParameter caddress = new SqlParameter("@caddress", SqlDbType.VarChar);
                cname.Value = customer.Name;
                csurname.Value = customer.SurName;
                cidnumber.Value = customer.IdentityNumber;
                caddress.Value = customer.Address;
               // cid.Value = customer.Id;

                //command.Parameters.Add(cid);
                command.Parameters.Add(cname);
                command.Parameters.Add(csurname);
                command.Parameters.Add(cidnumber);
                command.Parameters.Add(caddress);                
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }


        public static Product[] GetAllProducts()
        {
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand command = new SqlCommand("SELECT * FROM Products", conn);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<Product> productList = new List<Product>();
            if (!reader.HasRows)
            {
                return null;
            }
            while (reader.Read())
            {
                productList.Add(new Product(reader.GetInt32(0), reader.GetString(1), reader.GetDouble(2), reader.GetString(3), reader.GetString(4)));
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Dispose();
            }
            return productList.ToArray();
        }

        public static bool updateProduct(Product product)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("UPDATE Products SET Name = @pname, Price=@pprice, Model=@pmodel, Color=@pcolor Where id = @pId", conn);
                SqlParameter pname = new SqlParameter("@pname", SqlDbType.VarChar);
                SqlParameter pprice = new SqlParameter("@pprice", SqlDbType.Float);
                SqlParameter pmodel = new SqlParameter("@pmodel", SqlDbType.VarChar);
                SqlParameter pcolor = new SqlParameter("@pcolor", SqlDbType.VarChar);
                SqlParameter pid = new SqlParameter("@pId", SqlDbType.Int);
                pname.Value = product.Name;
                pprice.Value = product.Price;
                pmodel.Value = product.Model;
                pcolor.Value = product.Color;
                pid.Value = product.Id;

                command.Parameters.Add(pname);
                command.Parameters.Add(pprice);
                command.Parameters.Add(pmodel);
                command.Parameters.Add(pcolor);
                command.Parameters.Add(pid);
                command.Connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {

                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static bool insertProduct(Product product)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO Products (Name, Price, Model, Color)  VALUES (@pname, @pprice, @pmodel, @pcolor)", conn);
                command.Connection.Open();
                // SqlParameter cid = new SqlParameter("@cId", SqlDbType.Int);
                SqlParameter pname = new SqlParameter("@pname", SqlDbType.VarChar);
                SqlParameter pprice = new SqlParameter("@pprice", SqlDbType.Float);
                SqlParameter pmodel = new SqlParameter("@pmodel", SqlDbType.VarChar);
                SqlParameter pcolor = new SqlParameter("@pcolor", SqlDbType.VarChar);
                pname.Value = product.Name;
                pprice.Value = product.Price;
                pmodel.Value = product.Model;
                pcolor.Value = product.Color;

                command.Parameters.Add(pname);
                command.Parameters.Add(pprice);
                command.Parameters.Add(pmodel);
                command.Parameters.Add(pcolor);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }


        public static CreditCard[] GetAllCreditCards()
        {
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand command = new SqlCommand("SELECT * FROM CreditCards", conn);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<CreditCard> creditCardList = new List<CreditCard>();
            if (!reader.HasRows)
            {
                return null;
            }
            while (reader.Read())
            {
                creditCardList.Add(new CreditCard(reader.GetInt32(0), reader.GetString(1), reader.GetInt32(2), reader.GetInt32(3)));
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Dispose();
            }
            return creditCardList.ToArray();
        }

        public static bool updateCreditCard (CreditCard creditCard)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("UPDATE CreditCards SET CardName = @ccardname, TaxPercentage=@ctax, MaxInstallment=@cmax Where id = @ccId", conn);
                SqlParameter ccardname = new SqlParameter("@ccardname", SqlDbType.VarChar);
                SqlParameter ctax = new SqlParameter("@ctax", SqlDbType.Int);
                SqlParameter cmax = new SqlParameter("@cmax", SqlDbType.Int);
                SqlParameter ccid = new SqlParameter("@ccId", SqlDbType.Int);
                ccardname.Value = creditCard.CardName;
                ctax.Value = creditCard.TaxPercentage;
                cmax.Value = creditCard.MaxInstallments;
                ccid.Value = creditCard.Id;

                command.Parameters.Add(ccardname);
                command.Parameters.Add(ctax);
                command.Parameters.Add(cmax);
                command.Parameters.Add(ccid);
                command.Connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {

                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static bool insertCreditCard(CreditCard creditCard)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO CreditCards (CardName, TaxPercentage, MaxInstallment)  VALUES (@ccardname, @ctax, @cmax)", conn);
                command.Connection.Open();
                SqlParameter ccardname = new SqlParameter("@ccardname", SqlDbType.VarChar);
                SqlParameter ctax = new SqlParameter("@ctax", SqlDbType.Int);
                SqlParameter cmax = new SqlParameter("@cmax", SqlDbType.Int);
                ccardname.Value = creditCard.CardName;
                ctax.Value = creditCard.TaxPercentage;
                cmax.Value = creditCard.MaxInstallments;

                command.Parameters.Add(ccardname);
                command.Parameters.Add(ctax);
                command.Parameters.Add(cmax);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }



        
        public static bool insertSales(Sales sales)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO Sales (CustomerId, ProductId, CreditCardId, UserId, InstallmentNo, ExpiryDate, Price, Charged)  VALUES (@scustomerId, @sproductId, @screditcardId, @suserId, @sinstallmentNo, @sexpiryDate, @sprice, 0)", conn);
                command.Connection.Open();
                SqlParameter scustomerId = new SqlParameter("@scustomerId", SqlDbType.Int);
                SqlParameter sproductId = new SqlParameter("@sproductId", SqlDbType.Int);
                SqlParameter screditCardId = new SqlParameter("@screditCardId", SqlDbType.Int);
                SqlParameter suserId = new SqlParameter("@suserId", SqlDbType.Int);
                SqlParameter sinstallmentNo = new SqlParameter("@sinstallmentNo", SqlDbType.Int);
                SqlParameter sexpiryDate = new SqlParameter("@sexpiryDate", SqlDbType.Date);
                SqlParameter sprice = new SqlParameter("@sprice", SqlDbType.Float);
                scustomerId.Value = sales.CustomerId;
                sproductId.Value = sales.ProductId;
                screditCardId.Value = sales.CreditCardId;
                suserId.Value = sales.UserId;
                sinstallmentNo.Value = sales.InstallmentNo;
                sexpiryDate.Value = sales.ExpiryDate;
                sprice.Value = sales.Price;

                command.Parameters.Add(scustomerId);
                command.Parameters.Add(sproductId);
                command.Parameters.Add(screditCardId);
                command.Parameters.Add(suserId);
                command.Parameters.Add(sinstallmentNo);
                command.Parameters.Add(sexpiryDate);
                command.Parameters.Add(sprice);

                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static DataTable getUserCustomerUnpaidPayments(int userId, int customerId)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                
                SqlCommand command = new SqlCommand("SELECT * FROM V_Payments WHERE CustomerId = @pCustomerId and UserId = @pUserId and Charged=0", conn);
                command.Connection.Open();
                SqlParameter pcustomerId = new SqlParameter("@pCustomerId", SqlDbType.Int);
                SqlParameter pUserId = new SqlParameter("@pUserId", SqlDbType.Int);
                pcustomerId.Value = customerId;
                pUserId.Value = userId;

                command.Parameters.Add(pcustomerId);
                command.Parameters.Add(pUserId);

                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();

                da.Fill(dt);

                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static bool tahsilEt(int salesId)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("UPDATE Sales SET Charged=1  Where id = @sId", conn);
                SqlParameter sId = new SqlParameter("@sId", SqlDbType.Int);
                sId.Value = salesId;
                command.Parameters.Add(sId);
                command.Connection.Open();
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {

                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }

        }

        public static DataTable getAllSalesByCustomer(int customerId, int charged)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("SELECT * FROM V_AllSales WHERE CustomerId = @sCustomerId and charged = @scharged", conn);
                command.Connection.Open();
                SqlParameter scustomerId = new SqlParameter("@sCustomerId", SqlDbType.Int);
                SqlParameter scharged = new SqlParameter("@scharged", SqlDbType.Int);
                scustomerId.Value = customerId;
                scharged.Value = charged;
                command.Parameters.Add(scustomerId);
                command.Parameters.Add(scharged);
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static DataTable getAllSalesByUser(int userId, int charged)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("SELECT * FROM V_AllSales WHERE UserId = @sUserId AND charged = @sCharged", conn);
                command.Connection.Open();
                SqlParameter suserId = new SqlParameter("@sUserId", SqlDbType.Int);
                SqlParameter scharged = new SqlParameter("@scharged", SqlDbType.Int);
                suserId.Value = userId;
                scharged.Value = charged;
                command.Parameters.Add(suserId);
                command.Parameters.Add(scharged);
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static DataTable getAllExpiredPayments()
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("SELECT * FROM V_AllSales WHERE Charged = 0 and expiryDate <= @pexpiryDate", conn);
                command.Connection.Open();
                SqlParameter pExpiryDate = new SqlParameter("@pExpiryDate", SqlDbType.Date);
                pExpiryDate.Value = DateTime.Now.Date;
                command.Parameters.Add(pExpiryDate);
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
            catch (Exception e)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static User[] GetAllUsers()
        {
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand command = new SqlCommand("SELECT * FROM Users Where UserType = 'S'", conn);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<User> userList = new List<User>();
            if (!reader.HasRows)
            {
                return null;
            }
            while (reader.Read())
            {
                userList.Add(new User(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetInt32(6), reader.GetInt32(7), reader.GetInt32(8)));
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Dispose();
            }
            return userList.ToArray();
        }

        public static bool isUserExists(string userName)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {

                SqlCommand command = new SqlCommand("SELECT * FROM Users WHERE UserName = @pUserName", conn);
                command.Connection.Open();
                SqlParameter suserName = new SqlParameter("@pUserName", SqlDbType.VarChar);
                suserName.Value = userName;
                command.Parameters.Add(suserName);
                SqlDataReader s = command.ExecuteReader();
                if (s.HasRows)
                {
                    return true;
                } else
                {
                    return false;
                }
                
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static bool insertUser(User user)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("INSERT INTO Users (UserName, Password, Name, Surname, UserType, AccountLocked, ResetPassword, RetryCount)  VALUES (@puserName, @ppassword, @pname, @psurname, @pusertype, @pacclock, @preset, @pretry)", conn);
                command.Connection.Open();
                SqlParameter pusername = new SqlParameter("@pusername", SqlDbType.VarChar);
                SqlParameter ppassword = new SqlParameter("@ppassword", SqlDbType.VarChar);
                SqlParameter pname = new SqlParameter("@pname", SqlDbType.VarChar);
                SqlParameter psurname = new SqlParameter("@psurname", SqlDbType.VarChar);
                SqlParameter pusertype = new SqlParameter("@pusertype", SqlDbType.VarChar);
                SqlParameter pacclock = new SqlParameter("@pacclock", SqlDbType.Int);
                SqlParameter preset = new SqlParameter("@preset", SqlDbType.Int);
                SqlParameter pretry = new SqlParameter("@pretry", SqlDbType.Int);
                pusername.Value = user.UserName;
                ppassword.Value = user.Password;
                pname.Value = user.Name;
                psurname.Value = user.Surname;
                pusertype.Value = user.UserType;
                pacclock.Value = user.AccountLocked;
                preset.Value = user.ResetPassword;
                pretry.Value = user.RetryCount;

                command.Parameters.Add(pusername);
                command.Parameters.Add(ppassword);
                command.Parameters.Add(pname);
                command.Parameters.Add(psurname);
                command.Parameters.Add(pusertype);
                command.Parameters.Add(pacclock);
                command.Parameters.Add(preset);
                command.Parameters.Add(pretry);
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

        public static User[] getLockedUsers()
        {
            SqlConnection conn = new SqlConnection(cs);
            SqlCommand command = new SqlCommand("SELECT * FROM Users Where UserType = 'S' and AccountLocked = 1", conn);
            command.Connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            List<User> userList = new List<User>();
            if (!reader.HasRows)
            {
                return null;
            }
            while (reader.Read())
            {
                userList.Add(new User(reader.GetInt32(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5), reader.GetInt32(6), reader.GetInt32(7), reader.GetInt32(8)));
            }
            if (conn.State == ConnectionState.Open)
            {
                conn.Dispose();
            }
            return userList.ToArray();
        }

        public static bool releaseUserLock(string password, int id)
        {
            SqlConnection conn = new SqlConnection(cs);
            try
            {
                SqlCommand command = new SqlCommand("Update Users Set password = @ppassword, accountlocked=0, resetpassword=1, retrycount=0 where id = @pid", conn);
                command.Connection.Open();
                SqlParameter ppassword = new SqlParameter("@ppassword", SqlDbType.VarChar);
                SqlParameter pid = new SqlParameter("@pid", SqlDbType.Int);
                ppassword.Value = password;
                pid.Value = id;

                command.Parameters.Add(ppassword);
                command.Parameters.Add(pid);
              
                command.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
        }

    }
}
