﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    //User objesinin sınıfı
    //User bir person olduğu için, IPerson interface'i implement edilmiştir
    //Buna göre concatFullName metodu eklenmek zorundadır
    public class User : IPerson<User>
    {
        private int _id;
        private string _userName;
        private string _password;
        private string _name;
        private string _surname;
        private string _userType;
        private int _accountLocked;
        private int _resetPassword;
        private int _retryCount;
        private String _fullName;

        public User(int _id, string _userName, string _password, string _name, string _surname, string _userType, int _accountLocked, int _resetPassword, int _retryCount)
        {
            this._id = _id;
            this._userName = _userName;
            this._password = _password;
            this._name = _name;
            this._surname = _surname;
            this._userType = _userType;
            this._accountLocked = _accountLocked;
            this._resetPassword = _resetPassword;
            this._retryCount = _retryCount;
        }

        public User(string _userName, string _password, string _name, string _surname, string _userType, int _accountLocked, int _resetPassword, int _retryCount)
        {
            this._userName = _userName;
            this._password = _password;
            this._name = _name;
            this._surname = _surname;
            this._userType = _userType;
            this._accountLocked = _accountLocked;
            this._resetPassword = _resetPassword;
            this._retryCount = _retryCount;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string UserName
        {
            get
            {
                return _userName;
            }

            set
            {
                _userName = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }

            set
            {
                _password = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string Surname
        {
            get
            {
                return _surname;
            }

            set
            {
                _surname = value;
            }
        }

        public string UserType
        {
            get
            {
                return _userType;
            }

            set
            {
                _userType = value;
            }
        }

        public int AccountLocked
        {
            get
            {
                return _accountLocked;
            }

            set
            {
                _accountLocked = value;
            }
        }

        public int ResetPassword
        {
            get
            {
                return _resetPassword;
            }

            set
            {
                _resetPassword = value;
            }
        }

        public int RetryCount
        {
            get
            {
                return _retryCount;
            }

            set
            {
                _retryCount = value;
            }
        }

        public string FullName
        {
            get
            {
                return concatFullName();
            }

        }

        public string concatFullName()
        {
            return _name + _surname;
        }
    }
}