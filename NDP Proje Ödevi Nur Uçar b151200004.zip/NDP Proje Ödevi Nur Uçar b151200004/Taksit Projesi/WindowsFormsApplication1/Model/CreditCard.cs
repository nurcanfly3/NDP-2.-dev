﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    //Kredi kartı objesinin sınıfı
    public class CreditCard
    {
        private int _id;
        private string _cardName;
        private int _taxPercentage;
        private int _maxInstallments;

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string CardName
        {
            get
            {
                return _cardName;
            }

            set
            {
                _cardName = value;
            }
        }

        public int TaxPercentage
        {
            get
            {
                return _taxPercentage;
            }

            set
            {
                _taxPercentage = value;
            }
        }

        public int MaxInstallments
        {
            get
            {
                return _maxInstallments;
            }

            set
            {
                _maxInstallments = value;
            }
        }

        public CreditCard(int _id, string _cardName, int _taxPercentage, int _maxInstallments)
        {
            this.Id = _id;
            this.CardName = _cardName;
            this.TaxPercentage = _taxPercentage;
            this.MaxInstallments = _maxInstallments;
        }

        public CreditCard(string _cardName, int _taxPercentage, int _maxInstallments)
        {
            this.CardName = _cardName;
            this.TaxPercentage = _taxPercentage;
            this.MaxInstallments = _maxInstallments;
        }
    }
}
