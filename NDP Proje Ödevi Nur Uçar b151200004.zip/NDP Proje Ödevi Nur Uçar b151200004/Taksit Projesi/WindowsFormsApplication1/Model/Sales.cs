﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    //Sales objesinin sınıfı
    public class Sales
    {
        private int _id;
        private int _customerId;
        private int _productId;
        private int _creditCardId;
        private int _userId;
        private int _installmentNo;
        private DateTime _expiryDate;
        private double _price;
        private int _charged;

        public Sales(int _id, int _customerId, int _productId, int _creditCardId, int _userId, int _installmentNo, DateTime _expiryDate, double _price, int _charged)
        {
            this._id = _id;
            this._customerId = _customerId;
            this._productId = _productId;
            this._creditCardId = _creditCardId;
            this._userId = _userId;
            this._installmentNo = _installmentNo;
            this._expiryDate = _expiryDate;
            this._price = _price;
            this._charged = _charged;
        }

        public Sales(int _customerId, int _productId, int _creditCardId, int _userId, int _installmentNo, DateTime _expiryDate, double _price, int _charged)
        {
            this._customerId = _customerId;
            this._productId = _productId;
            this._creditCardId = _creditCardId;
            this._userId = _userId;
            this._installmentNo = _installmentNo;
            this._expiryDate = _expiryDate;
            this._price = _price;
            this._charged = _charged;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public int CustomerId
        {
            get
            {
                return _customerId;
            }

            set
            {
                _customerId = value;
            }
        }

        public int ProductId
        {
            get
            {
                return _productId;
            }

            set
            {
                _productId = value;
            }
        }

        public int CreditCardId
        {
            get
            {
                return _creditCardId;
            }

            set
            {
                _creditCardId = value;
            }
        }

        public int UserId
        {
            get
            {
                return _userId;
            }

            set
            {
                _userId = value;
            }
        }

        public int InstallmentNo
        {
            get
            {
                return _installmentNo;
            }

            set
            {
                _installmentNo = value;
            }
        }

        public DateTime ExpiryDate
        {
            get
            {
                return _expiryDate;
            }

            set
            {
                _expiryDate = value;
            }
        }

        public double Price
        {
            get
            {
                return _price;
            }

            set
            {
                _price = value;
            }
        }

        public int Charged
        {
            get
            {
                return _charged;
            }

            set
            {
                _charged = value;
            }
        }
    }
}
