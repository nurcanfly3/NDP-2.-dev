﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    //Ürün objesinin sınıfı
    public class Product
    {
        int _id;
        string _name;
        double _price;
        string _model;
        string _color;

        public Product(int _id, string _name, double _price, string _model, string _color)
        {
            this._id = _id;
            this._name = _name;
            this._price = _price;
            this._model = _model;
            this._color = _color;
        }

        public Product(string _name, double _price, string _model, string _color)
        {
            this._name = _name;
            this._price = _price;
            this._model = _model;
            this._color = _color;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public double Price
        {
            get
            {
                return _price;
            }

            set
            {
                _price = value;
            }
        }

        public string Model
        {
            get
            {
                return _model;
            }

            set
            {
                _model = value;
            }
        }

        public string Color
        {
            get
            {
                return _color;
            }

            set
            {
                _color = value;
            }
        }
    }
}
