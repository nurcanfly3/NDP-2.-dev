﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    //Müşteri objesinin sınıfı
    //Müşteri bir person olduğu için, IPerson interface'i implement edilmiştir
    //Buna göre concatFullName metodu eklenmek zorundadır
    public class Customer : IPerson<Customer>
    {
        private int _id;
        private string _name;
        private string _surName;
        private int _identityNumber;
        private string _address;

        public Customer(int _id, string _name, string _surName, int _identityNumber, string _address)
        {
            this._id = _id;
            this._name = _name;
            this._surName = _surName;
            this._identityNumber = _identityNumber;
            this._address = _address;
        }

        public Customer(string _name, string _surName, int _identityNumber, string _address)
        {
            this._name = _name;
            this._surName = _surName;
            this._identityNumber = _identityNumber;
            this._address = _address;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string SurName
        {
            get
            {
                return _surName;
            }

            set
            {
                _surName = value;
            }
        }

        public int IdentityNumber
        {
            get
            {
                return _identityNumber;
            }

            set
            {
                _identityNumber = value;
            }
        }

        public string Address
        {
            get
            {
                return _address;
            }

            set
            {
                _address = value;
            }
        }


        public string FullName
        {
            get
            {
                return concatFullName();
            }

        }

        public string concatFullName()
        {
            return _name + _surName;
        }
    }

    
}