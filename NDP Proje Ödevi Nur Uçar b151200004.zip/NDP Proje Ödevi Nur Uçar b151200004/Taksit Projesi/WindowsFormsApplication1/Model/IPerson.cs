﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Model
{
    public interface IPerson<T>
    {
         String concatFullName();
    }
}
