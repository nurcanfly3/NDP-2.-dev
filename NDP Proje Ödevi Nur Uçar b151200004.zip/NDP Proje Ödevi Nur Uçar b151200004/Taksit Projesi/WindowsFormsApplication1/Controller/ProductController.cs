﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaksitApp.Model;

namespace TaksitApp.Controller
{
    class ProductController
    {
        //Tüm ürünleri object array olarak getiren metod
        public Product[] getAllProducts()
        {
            return DBOperations.GetAllProducts();
        }

        //Ürünü veritabanında güncelleyen metod
        public bool updateProduct(Product product)
        {
            return DBOperations.updateProduct(product);
        }

        //Veritabanına yeni ürün kaydeden metod
        public bool insertProduct(Product product)
        {
            return DBOperations.insertProduct(product);
        }
    }
}
