﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaksitApp.Model;

namespace TaksitApp.Controller
{
    class AdminController
    {
        //Müşteri bazlı satışları getiren metod
        public DataTable getAllSalesByCustomer(int customerId, int charged)
        {
            return DBOperations.getAllSalesByCustomer(customerId, charged);
        }

        //Kullanıcı bazlı satışları getiren metod
        public DataTable getAllSalesByUser(int customerId, int charged)
        {
            return DBOperations.getAllSalesByUser(customerId, charged);
        }

        //Vadesi geçen tüm tahsilatları getiren metod
        public DataTable getAllExpiredPayments()
        {
            return DBOperations.getAllExpiredPayments();
        }

        //Tüm kullanıcıları getiren metod
        public User[] getAllUsers()
        {
            return DBOperations.GetAllUsers();
        }

        //Kullanıcı daha önce kaydedildi mi kontrolü yapan metod
        public bool isUserExists(string userName)
        {
            return DBOperations.isUserExists(userName);
        }

        //Kullanıcıyı veritabanına kaydeden metod
        public bool insertUser(User user)
        {
            return DBOperations.insertUser(user);
        }

        //Kilitli hesapları getiren metod
        public User[] getLockedUsers()
        {
            return DBOperations.getLockedUsers();
        }

        //Kilitlenen hesabı veritabanında güncelleyen metod
        public bool releaseUserLock(string password, int id)
        {
           return DBOperations.releaseUserLock(password, id);
        }

    }
}
