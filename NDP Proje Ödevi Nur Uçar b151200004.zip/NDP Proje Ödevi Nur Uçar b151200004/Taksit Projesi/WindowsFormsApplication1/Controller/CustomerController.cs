﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using TaksitApp.Model;


namespace TaksitApp.Controller
{
    class CustomerController
    {
        //Tüm müşterileri object array olarak getiren metod
        public Customer[] getAllCustomers()
        {
            return DBOperations.GetAllCustomers();
        }

        //Müşteriyi veritabanında güncelleyen metod
        public bool updateCustomer(Customer customer)
        {
            return DBOperations.updateCustomer(customer);
        }

        //Yeni müşteri insert eden metod
        public bool insertCustomer(Customer customer)
        {
            return DBOperations.insertCustomer(customer);
        }

    }
}
