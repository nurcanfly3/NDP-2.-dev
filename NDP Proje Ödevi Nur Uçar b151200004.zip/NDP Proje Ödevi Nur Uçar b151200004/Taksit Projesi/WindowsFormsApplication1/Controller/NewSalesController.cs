﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaksitApp.Model;

namespace TaksitApp.Controller
{
    class NewSalesController
    {
        //Kuruş farkını taksit sayısına göre hesaplayan metod
        public double kurusFarkiHesapla(int taksitSayisi, double tutar)
        {
            return  tutar - System.Math.Round((tutar/ taksitSayisi),2)*taksitSayisi;
        }

        //Yeni satışı veritabanına kaydeden metod
        public bool insertSales(Sales sales)
        {
            return DBOperations.insertSales(sales);
        }
    }

    
}
