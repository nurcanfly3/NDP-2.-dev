﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaksitApp.Controller
{
    class PaymentController
    {
        //Tahsil edilmeyen müşteri ödemelerini kullanıcıya göre getiren metod
        public DataTable getUserCustomerUnpaidPayments(int userId, int customerId)
        {
            return DBOperations.getUserCustomerUnpaidPayments(userId, customerId);
        }

        //Satış tahsilatını veritabanına kaydeden metod
        public bool tahsilEt(int salesId)
        {
            return DBOperations.tahsilEt(salesId);
        }

    }
}
