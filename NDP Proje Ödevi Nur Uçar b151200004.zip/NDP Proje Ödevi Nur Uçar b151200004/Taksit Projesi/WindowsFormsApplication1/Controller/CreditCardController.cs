﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaksitApp.Model;

namespace TaksitApp.Controller
{
    class CreditCardController
    {
        //Tüm kredi kartlarını getiren metod
        public CreditCard[] getAllCreditCards()
        {
            return DBOperations.GetAllCreditCards();
        }

        //Kredi kartını update eden metod
        public bool updateCreditCard(CreditCard creditCard)
        {
            return DBOperations.updateCreditCard(creditCard);
        }

        //Yeni Kredi kartını veritabanına insert eden metod
        public bool insertCreditCard(CreditCard creditCard)
        {
            return DBOperations.insertCreditCard(creditCard);
        }
    }
}
