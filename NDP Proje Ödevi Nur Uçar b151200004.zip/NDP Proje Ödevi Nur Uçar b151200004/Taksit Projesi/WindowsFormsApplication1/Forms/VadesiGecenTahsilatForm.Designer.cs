﻿namespace TaksitApp.Forms
{
    partial class VadesiGecenTahsilatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTahsilat = new System.Windows.Forms.Label();
            this.gvVadesiGecenler = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvVadesiGecenler)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTahsilat
            // 
            this.lblTahsilat.AutoSize = true;
            this.lblTahsilat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTahsilat.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblTahsilat.Location = new System.Drawing.Point(47, 19);
            this.lblTahsilat.Name = "lblTahsilat";
            this.lblTahsilat.Size = new System.Drawing.Size(311, 22);
            this.lblTahsilat.TabIndex = 26;
            this.lblTahsilat.Text = "Vadesi Geçen Tahsilatları Görüntüle";
            // 
            // gvVadesiGecenler
            // 
            this.gvVadesiGecenler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvVadesiGecenler.Location = new System.Drawing.Point(12, 61);
            this.gvVadesiGecenler.Name = "gvVadesiGecenler";
            this.gvVadesiGecenler.Size = new System.Drawing.Size(375, 173);
            this.gvVadesiGecenler.TabIndex = 27;
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBack.Location = new System.Drawing.Point(91, 255);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(215, 23);
            this.btnBack.TabIndex = 32;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // VadesiGecenTahsilatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(399, 290);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.gvVadesiGecenler);
            this.Controls.Add(this.lblTahsilat);
            this.Name = "VadesiGecenTahsilatForm";
            this.Text = "VadesiGecenTahsilatForm";
            ((System.ComponentModel.ISupportInitialize)(this.gvVadesiGecenler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTahsilat;
        private System.Windows.Forms.DataGridView gvVadesiGecenler;
        private System.Windows.Forms.Button btnBack;
    }
}