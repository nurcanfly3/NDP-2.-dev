﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using TaksitApp.Model;

namespace TaksitApp
{
    public partial class ResetPasswordForm : Form
    {
        String cs = ConfigurationManager.ConnectionStrings["TaksitDBConnectionString"].ConnectionString.ToString();
        User user;

        public ResetPasswordForm(User user)
        {
            //Hangi user şifresinin değişeceği bilgisi gerektiğinden constructor'da user objesi dolduruluyor
            InitializeComponent();
            this.user = user;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            //Şifre uygun değilse uyarılar veriliyor
            if (txtNewPassword.Text.Length < 8)
            {
                MessageBox.Show("Şifreniz en az 8 karakterli olmalıdır!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNewPassword.Clear();
                txtNewPassword.Focus();
                return;
            }

            if (txtNewPassword.Text.ToString() != txtNewPassword2.Text.ToString())
            {
                MessageBox.Show("Şifreler uyumlu değil, lütfen tekrar deneyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNewPassword.Clear();
                txtNewPassword2.Clear();
                txtNewPassword.Focus();
                return;
            }

            string newPassword = txtNewPassword.Text;

            try
            {
                //İlgili user bilgisinin şifresi veritabanında update ediliyor
                SqlConnection conn = default(SqlConnection);
                conn = new SqlConnection(cs);
                SqlCommand command = conn.CreateCommand();
                //command = new SqlCommand("UPDATE Users SET Password = @upassword, ResetPassword = 0 Where id = @Id", conn);
                command.Connection.Open();
                command.CommandText = "UPDATE Users SET password = @upassword, resetpassword = 0, retrycount=0 Where id = @uId";
                //Parametreler set ediliyor
                SqlParameter uPassword = new SqlParameter("@upassword", SqlDbType.VarChar);
                SqlParameter uId = new SqlParameter("@uId", SqlDbType.Int);
                uPassword.Value = newPassword;
                uId.Value = this.user.Id;
                command.Parameters.Add(uPassword);
                command.Parameters.Add(uId);             
                //Update komutu veritabanında çalıştırılıyor
                int recordsAffected = command.ExecuteNonQuery();
                Console.WriteLine("records:" + recordsAffected);
                
                MessageBox.Show("Şifreniz başarıyla değiştirildi", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
                this.Hide();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtNewPassword_TextChanged(object sender, EventArgs e)
        {
           
        }


    }
}
