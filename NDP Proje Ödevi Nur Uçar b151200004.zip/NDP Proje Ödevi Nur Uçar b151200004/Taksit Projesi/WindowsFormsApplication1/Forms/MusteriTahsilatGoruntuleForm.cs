﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Model;
using TaksitApp.Controller;

namespace TaksitApp.Forms
{
    public partial class MusteriTahsilatGoruntuleForm : Form
    {
        Customer[] customers;
        AdminController ac = new AdminController();
        CustomerController cc = new CustomerController();

        public MusteriTahsilatGoruntuleForm()
        {
            //Bu ekranda sadece grid view, controller aracılığıyla ve veritabanında bir view aracılığıyla dolduruluyor
            InitializeComponent();
            customers = cc.getAllCustomers();
            BindingSource theBindingSource = new BindingSource();
            theBindingSource.DataSource = customers;
            cmbMusteri.DataSource = theBindingSource.DataSource;
            cmbMusteri.DisplayMember = "FullName";
            cmbMusteri.ValueMember = "Id";

        }

        //Grid view'ı dolduran metod
        private void refreshGridView()
        {
            int charged;

            //Radio button kontrolleri burada yapılıyor
            if (rbOdenen.Checked)
            {
                charged = 1;
            } else
            {
                charged = 0;
            }

            //Seçilen müşteri bilgisiyle satışlar getiriliyor
            Customer selectedCustomer = (Customer)cmbMusteri.SelectedItem;
            if (selectedCustomer == null)
            {
                return;
            }
            DataTable dt = ac.getAllSalesByCustomer(selectedCustomer.Id, charged);
            if (dt == null)
            {
                gvGoruntule = null;
                return;
            }
            gvGoruntule.DataSource = dt;
            dt.Columns[5].ColumnName = "Satışçı Adı";
            dt.Columns[6].ColumnName = "Satışçı Soyadı";
            dt.Columns[7].ColumnName = "Ürün Adı";
            dt.Columns[8].ColumnName = "Ürün Modeli";
            dt.Columns[9].ColumnName = "Kredi Kartı";
            dt.Columns[10].ColumnName = "Aylık Faiz Oranı(%)";
            dt.Columns[11].ColumnName = "Vade Tarihi";
            dt.Columns[12].ColumnName = "Taksit No";
            dt.Columns[13].ColumnName = "Tutar";

            gvGoruntule.Columns[0].Visible = false;
            gvGoruntule.Columns[1].Visible = false;
            gvGoruntule.Columns[2].Visible = false;
            gvGoruntule.Columns[3].Visible = false;
            gvGoruntule.Columns[4].Visible = false;
            foreach (DataGridViewRow row in gvGoruntule.Rows)
            {
                //Vadesi geçen tahsilatlar gridview üzerinde kırmızıya boyanıyor
                if (DateTime.Parse(row.Cells[11].Value.ToString()).Date <= DateTime.Now.Date && charged == 0)
                    row.DefaultCellStyle.BackColor = Color.Red;
            }


        }

        //Değişen radio box ve comboboxlarda gridview güncelleniyor
        private void cmbMusteri_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshGridView();
        }

        private void rbOdenen_CheckedChanged(object sender, EventArgs e)
        {
            refreshGridView();
        }

        private void rbOdenmeyen_CheckedChanged(object sender, EventArgs e)
        {
            refreshGridView();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
