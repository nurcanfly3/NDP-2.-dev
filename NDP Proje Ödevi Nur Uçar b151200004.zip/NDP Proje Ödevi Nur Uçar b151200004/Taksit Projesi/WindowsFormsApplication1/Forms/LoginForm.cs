﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using TaksitApp.Model;
using TaksitApp.Forms;

namespace TaksitApp
{
    
    public partial class LoginForm : Form
    {
        String cs = ConfigurationManager.ConnectionStrings["TaksitDBConnectionString"].ConnectionString.ToString();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

      
        private void btnLogin_Click(object sender, EventArgs e)
        {
            int uId;
            String userName;
            String uPassword;
            String name;
            String surName;
            string userType;
            int resetPassword;
            int retryCount;
            int accountLocked;

            if (txtUserName.Text == "")
            {
                MessageBox.Show("Kullanıcı adı boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtUserName.Focus();
                return;
            }

            try
            {
                SqlConnection conn = default(SqlConnection);
                conn = new SqlConnection(cs);

                SqlCommand command = default(SqlCommand);

                command = new SqlCommand("SELECT Id, Username, Password, Name, Surname, UserType, AccountLocked, ResetPassword, RetryCount FROM Users WHERE Username = @Username", conn);

                SqlParameter uName = new SqlParameter("@Username", SqlDbType.VarChar);
  
                uName.Value = txtUserName.Text;

                command.Parameters.Add(uName);

                command.Connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (!reader.HasRows)
                {
                    txtUserName.Clear();
                    txtPassword.Clear();
                    txtUserName.Focus();
                    MessageBox.Show("Yanlış Kullanıcı Adı", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Dispose();
                    }
                    return;
                }
                reader.Read();

                uId = reader.GetInt32(0);
                userName = reader.GetString(1);
                uPassword = reader.GetString(2);
                name = reader.GetString(3);
                surName = reader.GetString(4);
                userType = reader.GetString(5);
                accountLocked = reader.GetInt32(6);
                resetPassword = reader.GetInt32(7);
                retryCount = reader.GetInt32(8);
                
                
                reader.Close();

                if (accountLocked == 1)
                {
                    if (userType == "Y")
                    {
                        MessageBox.Show("Yönetici şifresini 3 kez üst üste yanlış şifre girdiğiniz için hesabınız kilitlenmiştir, lütfen IT iletişime geçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("3 kez üst üste yanlış şifre girdiğiniz için hesabınız kilitlenmiştir, lütfen yöneticinizle iletişime geçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                if (txtPassword.Text.ToString().Trim() != uPassword.ToString().Trim())
                {
                    
                    if (retryCount < 3)
                    {
                        command.CommandText = "UPDATE Users SET RetryCount = @retryCount Where Username = @uname";
                        command.Parameters.AddWithValue("@retryCount", ++retryCount);
                        command.Parameters.AddWithValue("@uname", txtUserName.Text);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Yanlış şifre girdiniz, kalan deneme hakkı:" + (3 - retryCount), "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    } else
                    {
                        command.CommandText = "UPDATE Users SET RetryCount = @retryCount, AccountLocked = 1 Where Username = @uname";
                        command.Parameters.AddWithValue("@retryCount", ++retryCount);
                        command.Parameters.AddWithValue("@uname", txtUserName.Text);
                        command.ExecuteNonQuery();
                        MessageBox.Show("3 kez üst üste yanlış şifre girdiğiniz için hesabınız kilitlenmiştir, lütfen yöneticinizle iletişime geçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    txtUserName.Clear();
                    txtPassword.Clear();
                    txtUserName.Focus();
                } else
                {
                    if (retryCount > 0)
                    {
                        command.CommandText = "UPDATE Users SET RetryCount = 0 Where Username = @uname";
                        command.Parameters.AddWithValue("@uname", txtUserName.Text);
                        command.ExecuteNonQuery();
                    }

                    User user = new User(uId,userName,uPassword,name,surName,userType,accountLocked,resetPassword,retryCount);
                    if (user.ResetPassword == 1)
                    {
                        if (conn.State == ConnectionState.Open)
                        {
                            conn.Dispose();
                        }
                        MessageBox.Show("Şifrenizi değiştirmeniz gerekmektedir");
                        this.Hide();
                        ResetPasswordForm r = new ResetPasswordForm(user);
                        r.ShowDialog();
                        r = null;
                        this.Show();
                    }

                    switch (user.UserType)
                    {
                        case "S":
                            SatisciForm s = new SatisciForm(user);
                            this.Hide();
                            s.Show();
                            break;
                        case "Y":
                            YoneticiForm y = new YoneticiForm(user);
                            this.Hide();
                            y.Show();
                            break;
                    }

                }
 
                if (conn.State == ConnectionState.Open)
                {
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
    }


}
