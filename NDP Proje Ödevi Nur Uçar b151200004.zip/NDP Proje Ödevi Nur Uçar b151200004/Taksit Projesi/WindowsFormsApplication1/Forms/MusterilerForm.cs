﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;
using TaksitApp.Model;

namespace TaksitApp
{
    public partial class MusterilerForm : Form
    {
        Customer[] customers;
        Customer selectedCustomer;
        CustomerController cc = new CustomerController();
        public MusterilerForm(Customer[] customers)
        {
            //Constructor'a tüm müşteri bilgileri object array halinde getiriliyor
            this.customers = customers;
            
            InitializeComponent();
        }

        private void Musteriler_Load(object sender, EventArgs e)
        {
            //Gelen müşteri obje array'inden combobox dolduruluyor:
            BindingSource theBindingSource = new BindingSource();
            theBindingSource.DataSource = customers;
            cmbCustomers.DataSource = theBindingSource.DataSource;
            cmbCustomers.DisplayMember = "FullName";
            cmbCustomers.ValueMember = "Id";
        }

        private void cmbCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Combobox dan müşteri seçimi değiştiği zaman, ekrandaki alanlara seçilen müşteri bilgileri getiriliyor
            Object selectedItem = cmbCustomers.SelectedItem;
            Customer c = (Customer)selectedItem;
            selectedCustomer = c;
            txtCustomerId.Text = c.Id.ToString();
            txtCustomerName.Text = c.Name;
            txtCustomerSurname.Text = c.SurName;
            txtAddress.Text = c.Address;
            txtIdentityNo.Text = c.IdentityNumber.ToString();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            //integer olması gereken alanlar boş ise 0'a set ediliyor
            int identityNo;
            if (txtIdentityNo.Text != "")
            {
                identityNo = int.Parse(txtIdentityNo.Text);
            }
            else identityNo = 0;


            // Id alanı boş olduğu zaman insert çalışacak, boş değilse önceden kaydedilmiş bir müşteri seçili demektir
            // Bu durumda müşteri bilgileri bir objeye atılıp ilgili veritabanı tablosunda bilgileri güncellenecek
            if (txtCustomerId.Text == "")
            {
                Customer newCustomer = new Customer(txtCustomerName.Text, txtCustomerSurname.Text, identityNo, txtAddress.Text);
                if (cc.insertCustomer(newCustomer))
                {
                    MessageBox.Show("Yeni Müşteri Kaydedildi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                } else
                {
                    MessageBox.Show("Yeni Müşteri Kaydedilemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                selectedCustomer.Name = txtCustomerName.Text;
                selectedCustomer.SurName = txtCustomerSurname.Text;
                selectedCustomer.IdentityNumber = identityNo;
                selectedCustomer.Address = txtAddress.Text;
                if (cc.updateCustomer(selectedCustomer))
                {
                    MessageBox.Show("Müşteri bilgileri güncellendi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else
                {
                    MessageBox.Show("Müşteri bilgileri güncellenemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {
            // Yeni müşteri girmek için bu bilgileri ve id alanını temizleme işlemi yapılıyor:
            cmbCustomers.Hide();
            txtCustomerId.Text = "";
            txtCustomerName.Text = "";
            txtCustomerSurname.Text = "";
            txtIdentityNo.Text = "";
            txtAddress.Text = "";

        }

        private void txtIdentityNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Yalnızca silme tuşu ve yalnızca rakamlara izin vermek için yazılan kod:
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == 8);
        }
    }
}
