﻿namespace TaksitApp.Forms
{
    partial class YoneticiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblYonetici = new System.Windows.Forms.Label();
            this.lblAdmin = new System.Windows.Forms.Label();
            this.btnMusteriBazli = new System.Windows.Forms.Button();
            this.btnKullaniciBazli = new System.Windows.Forms.Button();
            this.btnVadesiGecen = new System.Windows.Forms.Button();
            this.btnSatisciEkle = new System.Windows.Forms.Button();
            this.btnKilitlenen = new System.Windows.Forms.Button();
            this.btnSifreDegistir = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblYonetici
            // 
            this.lblYonetici.AutoSize = true;
            this.lblYonetici.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblYonetici.ForeColor = System.Drawing.Color.Maroon;
            this.lblYonetici.Location = new System.Drawing.Point(95, 9);
            this.lblYonetici.Name = "lblYonetici";
            this.lblYonetici.Size = new System.Drawing.Size(148, 20);
            this.lblYonetici.TabIndex = 2;
            this.lblYonetici.Text = "YÖNETİCİ EKRANI";
            // 
            // lblAdmin
            // 
            this.lblAdmin.AutoSize = true;
            this.lblAdmin.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAdmin.Location = new System.Drawing.Point(12, 48);
            this.lblAdmin.Name = "lblAdmin";
            this.lblAdmin.Size = new System.Drawing.Size(51, 14);
            this.lblAdmin.TabIndex = 3;
            this.lblAdmin.Text = "Merhaba";
            // 
            // btnMusteriBazli
            // 
            this.btnMusteriBazli.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMusteriBazli.ForeColor = System.Drawing.Color.DarkRed;
            this.btnMusteriBazli.Location = new System.Drawing.Point(71, 74);
            this.btnMusteriBazli.Name = "btnMusteriBazli";
            this.btnMusteriBazli.Size = new System.Drawing.Size(195, 30);
            this.btnMusteriBazli.TabIndex = 4;
            this.btnMusteriBazli.Text = "Müşteri Bazlı Tahsilatlar";
            this.btnMusteriBazli.UseVisualStyleBackColor = true;
            this.btnMusteriBazli.Click += new System.EventHandler(this.btnMusteriBazli_Click);
            // 
            // btnKullaniciBazli
            // 
            this.btnKullaniciBazli.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKullaniciBazli.ForeColor = System.Drawing.Color.DarkRed;
            this.btnKullaniciBazli.Location = new System.Drawing.Point(71, 110);
            this.btnKullaniciBazli.Name = "btnKullaniciBazli";
            this.btnKullaniciBazli.Size = new System.Drawing.Size(195, 30);
            this.btnKullaniciBazli.TabIndex = 5;
            this.btnKullaniciBazli.Text = "Kullanıcı Bazlı Tahsilatlar";
            this.btnKullaniciBazli.UseVisualStyleBackColor = true;
            this.btnKullaniciBazli.Click += new System.EventHandler(this.btnKullaniciBazli_Click);
            // 
            // btnVadesiGecen
            // 
            this.btnVadesiGecen.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnVadesiGecen.ForeColor = System.Drawing.Color.DarkRed;
            this.btnVadesiGecen.Location = new System.Drawing.Point(71, 146);
            this.btnVadesiGecen.Name = "btnVadesiGecen";
            this.btnVadesiGecen.Size = new System.Drawing.Size(195, 30);
            this.btnVadesiGecen.TabIndex = 6;
            this.btnVadesiGecen.Text = "Vadesi Geçen Tahsilatlar";
            this.btnVadesiGecen.UseVisualStyleBackColor = true;
            this.btnVadesiGecen.Click += new System.EventHandler(this.btnVadesiGecen_Click);
            // 
            // btnSatisciEkle
            // 
            this.btnSatisciEkle.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSatisciEkle.ForeColor = System.Drawing.Color.DarkRed;
            this.btnSatisciEkle.Location = new System.Drawing.Point(71, 182);
            this.btnSatisciEkle.Name = "btnSatisciEkle";
            this.btnSatisciEkle.Size = new System.Drawing.Size(195, 30);
            this.btnSatisciEkle.TabIndex = 7;
            this.btnSatisciEkle.Text = "Satışçı Ekleme";
            this.btnSatisciEkle.UseVisualStyleBackColor = true;
            this.btnSatisciEkle.Click += new System.EventHandler(this.btnSatisciEkle_Click);
            // 
            // btnKilitlenen
            // 
            this.btnKilitlenen.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKilitlenen.ForeColor = System.Drawing.Color.DarkRed;
            this.btnKilitlenen.Location = new System.Drawing.Point(71, 218);
            this.btnKilitlenen.Name = "btnKilitlenen";
            this.btnKilitlenen.Size = new System.Drawing.Size(195, 30);
            this.btnKilitlenen.TabIndex = 8;
            this.btnKilitlenen.Text = "Kilitlenen Hesaplar";
            this.btnKilitlenen.UseVisualStyleBackColor = true;
            this.btnKilitlenen.Click += new System.EventHandler(this.btnKilitlenen_Click);
            // 
            // btnSifreDegistir
            // 
            this.btnSifreDegistir.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSifreDegistir.ForeColor = System.Drawing.Color.DarkRed;
            this.btnSifreDegistir.Location = new System.Drawing.Point(71, 254);
            this.btnSifreDegistir.Name = "btnSifreDegistir";
            this.btnSifreDegistir.Size = new System.Drawing.Size(195, 30);
            this.btnSifreDegistir.TabIndex = 9;
            this.btnSifreDegistir.Text = "Şifre Değiştir";
            this.btnSifreDegistir.UseVisualStyleBackColor = true;
            this.btnSifreDegistir.Click += new System.EventHandler(this.btnSifreDegistir_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.Red;
            this.btnCikis.Location = new System.Drawing.Point(71, 290);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(195, 37);
            this.btnCikis.TabIndex = 10;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // YoneticiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(338, 337);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnSifreDegistir);
            this.Controls.Add(this.btnKilitlenen);
            this.Controls.Add(this.btnSatisciEkle);
            this.Controls.Add(this.btnVadesiGecen);
            this.Controls.Add(this.btnKullaniciBazli);
            this.Controls.Add(this.btnMusteriBazli);
            this.Controls.Add(this.lblAdmin);
            this.Controls.Add(this.lblYonetici);
            this.Name = "YoneticiForm";
            this.Text = "YoneticiForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.YoneticiForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblYonetici;
        private System.Windows.Forms.Label lblAdmin;
        private System.Windows.Forms.Button btnMusteriBazli;
        private System.Windows.Forms.Button btnKullaniciBazli;
        private System.Windows.Forms.Button btnVadesiGecen;
        private System.Windows.Forms.Button btnSatisciEkle;
        private System.Windows.Forms.Button btnKilitlenen;
        private System.Windows.Forms.Button btnSifreDegistir;
        private System.Windows.Forms.Button btnCikis;
    }
}