﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Model;
using TaksitApp.Controller;

namespace TaksitApp
{
    public partial class YeniSatisForm : Form
    {
        //Satış ekranında gerekli olan objelerin tanımı yapılıyor
        CreditCard[] creditCards;
        Customer[] customers;
        Product[] products;
        User user;
        //Veritabanı işlemlei Controller objesi aracılığıyla yapılıyor
        NewSalesController n = new NewSalesController();

        public YeniSatisForm(User user, CreditCard[] creditCards, Customer[] customers, Product[] products)
        {
            //Constructor'dan gelen parametrelerle ilgili objeler dolduruluyor
            this.user = user;
            this.creditCards = creditCards;
            this.customers = customers;
            this.products = products;
            
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void YeniSatis_Load(object sender, EventArgs e)
        {
            //Ekran açılırken combobox'lar bu metod aracılığıyla dolduruluyor
            populateCombos();
        }

        private void populateCombos()
        {
            //Aşağıdaki kodda 3 adet combo box'un içi dolduruluyor
            BindingSource customersBindingSource = new BindingSource();
            customersBindingSource.DataSource = customers;
            cmbMusteri.DataSource = customersBindingSource.DataSource;
            cmbMusteri.DisplayMember = "FullName";
            cmbMusteri.ValueMember = "Id";

            BindingSource productsBindingSource = new BindingSource();
            productsBindingSource.DataSource = products;
            cmbUrun.DataSource = productsBindingSource.DataSource;
            cmbUrun.DisplayMember = "Name";
            cmbUrun.ValueMember = "Id";

            BindingSource cardsBindingSource = new BindingSource();
            cardsBindingSource.DataSource = creditCards;
            cmbKart.DataSource = cardsBindingSource.DataSource;
            cmbKart.DisplayMember = "CardName";
            cmbKart.ValueMember = "Id";
        }

        private void populateTaxCombo(int maxInstallment)
        {
            //Burada seçilen kredi kartında izin verilen maksimum taksit sayısına göre (maxInstallment)
            //cmbTaksit combobox'una 1'den maksimum taksit sayısına kadar loop içinde döngüdeki rakam ekleniyor 
            cmbTaksit.Items.Clear();
            for (int i = 1; i<= maxInstallment; i++)
            {
                cmbTaksit.Items.Add(i);
            }
        }

        private void cmbKart_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Seçilen kredi kartı değiştiğinde ilgili faiz oranı ve maksimum taksit sayısı değişeceğinden
            //Taksit sayısı combobox'u ve faiz oranı yeniden dolduruluyor
            Object selectedItem = cmbKart.SelectedItem;
            CreditCard c = (CreditCard)selectedItem;
            cmbTaksit.Text = "";
            populateTaxCombo(c.MaxInstallments);
            txtFaiz.Text = c.TaxPercentage.ToString();

            //Buna göre de gridView güncelleniyor
            populateGridView();
        }

        private void cmbTaksit_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Taksit alanı değiştirildiğinde gridview yeniden dolduruluyor
            //Eğer ürün bilgisi yoksa taksit sayısı seçimine izin verilmiyor
            //Çünkü grid view'ı dolduracak yeterli bilgi yok
            if (cmbUrun.SelectedItem == null)
            {
                MessageBox.Show("Lütfen önce ürün seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            populateGridView();

        }

        private void populateGridView()
        {
            //Burada gridview için gerekli tüm bilgiler mevcutsa, grid view dolduruluyor
            if (cmbUrun.SelectedItem == null || cmbTaksit.SelectedItem == null || cmbKart.SelectedItem == null)
                return;
            DataTable dt = new DataTable();
            dt.Clear();
            dt.Columns.Add("Taksit Sayısı");
            dt.Columns.Add("Vade Tarihi");
            dt.Columns.Add("Tutar");
            int installment;
            installment = (int)cmbTaksit.SelectedItem;
            
            //Her bir taksit için grid view'a yeni satır ekleniyor
            for (int i = 1; i <= installment; i++)
            {
                DataRow dr = dt.NewRow();
                //Taksit sayısı loop içinde 1'er artırılarak satıra ekleniyor
                dr["Taksit Sayısı"] = i;

                //Vade tarihi her bir satırda bir ay eklenerek satıra yazılıyor
                dr["Vade Tarihi"] = dtVadeTarihi.Value.Date.AddMonths(i-1);

                //Tutar alanı double'a cast ediliyor
                double toplamTutar = Double.Parse(txtTutar.Text);

                //Aylık faiz integer'a cast ediliyor
                int aylikFaiz = int.Parse(txtFaiz.Text);

                //Aylık tutar, toplam tutarın taksit sayısına bölünüp, 2 ondalığa kadar yuvarlanarak hesaplanıyor
                double price = System.Math.Round( toplamTutar / installment, 2);

                //Eğer yuvarlamadan dolayı oluşan kuruş farkı varsa, son taksite bu kuruş farkı ekleniyor
                if (i == installment)
                    //Kuruş farkı hesaplaması controller içindeki metodla yapılıyor
                    price = price + n.kurusFarkiHesapla(installment, toplamTutar);

                //En son aylık tutarı, aylık faiz oranı ile yüzdelik olarak çarpılıyor ve 2 ondalığa yuvarlanıyor
                price += price * aylikFaiz / 100;
                price = System.Math.Round(price, 2);
                dr["Tutar"] = price;

                //Tüm satır işlemi bittiğinde gridview'ı dolduran data table'a bu satır ekleniyor, ve loop'a devam ediliyor
                dt.Rows.Add(dr);
            }

            //loop bittiğinde grid view dolduruluyor
            gvSatis.DataSource = dt;
        }

        private void txtPesinat_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Peşinat alanına yalnızca double karakterleri girebilmek için eklenen kod
            if (Regex.IsMatch(txtPesinat.Text, @"\.\d\d") && e.KeyChar != 8) { e.Handled = true; }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Kaydet'e basıldığında satış için gerekli eksik bilgiler eksikse uyarı veriliyor
            if (cmbMusteri.SelectedItem == null)
            {
                {
                    MessageBox.Show("Lütfen müşteri seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmbMusteri.Focus();
                    return;
                }
            }

            if (cmbUrun.SelectedItem == null)
            {
                {
                    MessageBox.Show("Lütfen ürün seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmbUrun.Focus();
                    return;
                }
            }

            if (cmbKart.SelectedItem == null)
            {
                {
                    MessageBox.Show("Lütfen kredi kartı seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmbKart.Focus();
                    return;
                }
            }

            if (cmbTaksit.SelectedItem == null)
            {
                {
                    MessageBox.Show("Lütfen taksit sayısı seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cmbTaksit.Focus();
                    return;
                }
            }

            if (dtVadeTarihi.Value.Date< DateTime.Now.Date)
            {
                MessageBox.Show("Vade tarihi bugünden eski olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtVadeTarihi.Focus();
                return;
            }

            //Combobox seçimleri alınıyor
            Object selectedItem = cmbMusteri.SelectedItem;
            Customer cust = (Customer)selectedItem;
            selectedItem = cmbKart.SelectedItem;
            CreditCard cc = (CreditCard)selectedItem;
            selectedItem = cmbUrun.SelectedItem;
            Product p = (Product)selectedItem;
            int taksitSayisi;
            DateTime vadeTarihi;
            double tutar;

            //DataGridView'da gösterilen her satır satış olarak kaydediliyor
            //Bunun için sales objesi doldurulup controller aracılığıyla veritabanına kaydediliyor
            foreach (DataGridViewRow dgr in  gvSatis.Rows)
            {
                 DataRow dr = ((DataRowView)dgr.DataBoundItem).Row;
                 taksitSayisi = int.Parse(dr.ItemArray[0].ToString());
                 vadeTarihi = DateTime.Parse(dr.ItemArray[1].ToString()).Date;
                 tutar = double.Parse(dr.ItemArray[2].ToString());
                 Sales s = new Sales(cust.Id, p.Id, cc.Id, user.Id, taksitSayisi, vadeTarihi, tutar, 0);
                 n.insertSales(s);
            }

            MessageBox.Show("Satış kaydedildi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Hide();

        }

        private void cmbUrun_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Ürün deçimi değiştiğinde tutar değişeceği için gridview ve tutar alanı güncelleniyor
            Object selectedItem = cmbUrun.SelectedItem;
            Product p = (Product)selectedItem;
            txtTutar.Text = p.Price.ToString();
            cmbTaksit.Text = "";
            populateGridView();
        }

        private void btnPesinat_Click(object sender, EventArgs e)
        {
            //Girilen peşinat, toplam tutardan düşülecektir
            double pesinat;

            //Eğer peşinat formatı double formatı değilse hata veriliyor
            try
            {
                pesinat = double.Parse(txtPesinat.Text);
            } catch 
            {
                MessageBox.Show("Girilen peşinat formatı doğru değildir", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            //Peşinat düşmesi için ürün fiyatı gerektiğinden önce ürün seçilmesi gerekiyor
            if (txtTutar.Text == "")
            {
                MessageBox.Show("Lütfen önce ürün seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbUrun.Focus();
                return;
            }

            //Ürün fiyatından daha yüksek peşinat girilmesi engelleniyor
            if (pesinat > Double.Parse(txtTutar.Text))
            {
                MessageBox.Show("Peşinat tutarı, ürün tutarından fazla olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPesinat.Text = "0";
                txtPesinat.Focus();
                return;
            }
            Object selectedProduct = cmbUrun.SelectedItem;
            Product p = (Product)selectedProduct;
            txtTutar.Text  = (p.Price - pesinat).ToString();
            populateGridView();
        }

        private void dtVadeTarihi_ValueChanged(object sender, EventArgs e)
        {
            //Vade tarihi yeniden seçildiğinde grid view buna göre güncelleniyor
            if (dtVadeTarihi.Value.Date < DateTime.Now.Date)
            {
                MessageBox.Show("Vade tarihi bugünden eski olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtVadeTarihi.Value = DateTime.Now.Date;
                dtVadeTarihi.Focus();
                return;
            }
            populateGridView();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
