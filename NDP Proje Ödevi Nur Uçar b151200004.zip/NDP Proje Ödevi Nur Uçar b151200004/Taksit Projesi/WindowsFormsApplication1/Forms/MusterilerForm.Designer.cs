﻿namespace TaksitApp
{
    partial class MusterilerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblAdres = new System.Windows.Forms.Label();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblMusteriler = new System.Windows.Forms.Label();
            this.btnNewCustomer = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCustomerSurname = new System.Windows.Forms.TextBox();
            this.txtIdentityNo = new System.Windows.Forms.TextBox();
            this.txtCustomerId = new System.Windows.Forms.TextBox();
            this.lblMusteriID = new System.Windows.Forms.Label();
            this.lblMusteriAdi = new System.Windows.Forms.Label();
            this.lblMusteriSoyadi = new System.Windows.Forms.Label();
            this.lblKimlikNo = new System.Windows.Forms.Label();
            this.cmbCustomers = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(115, 178);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(201, 58);
            this.txtAddress.TabIndex = 3;
            // 
            // lblAdres
            // 
            this.lblAdres.AutoSize = true;
            this.lblAdres.ForeColor = System.Drawing.Color.Maroon;
            this.lblAdres.Location = new System.Drawing.Point(74, 198);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(34, 13);
            this.lblAdres.TabIndex = 9;
            this.lblAdres.Text = "Adres";
            // 
            // btnKaydet
            // 
            this.btnKaydet.ForeColor = System.Drawing.Color.Maroon;
            this.btnKaydet.Location = new System.Drawing.Point(136, 259);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(112, 23);
            this.btnKaydet.TabIndex = 10;
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Maroon;
            this.btnBack.Location = new System.Drawing.Point(254, 259);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(107, 23);
            this.btnBack.TabIndex = 11;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblMusteriler
            // 
            this.lblMusteriler.AutoSize = true;
            this.lblMusteriler.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMusteriler.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblMusteriler.Location = new System.Drawing.Point(146, 9);
            this.lblMusteriler.Name = "lblMusteriler";
            this.lblMusteriler.Size = new System.Drawing.Size(92, 22);
            this.lblMusteriler.TabIndex = 12;
            this.lblMusteriler.Text = "Müşteriler";
            // 
            // btnNewCustomer
            // 
            this.btnNewCustomer.ForeColor = System.Drawing.Color.Maroon;
            this.btnNewCustomer.Location = new System.Drawing.Point(12, 259);
            this.btnNewCustomer.Name = "btnNewCustomer";
            this.btnNewCustomer.Size = new System.Drawing.Size(118, 23);
            this.btnNewCustomer.TabIndex = 14;
            this.btnNewCustomer.Text = "Yeni Müşteri";
            this.btnNewCustomer.UseVisualStyleBackColor = true;
            this.btnNewCustomer.Click += new System.EventHandler(this.btnNewCustomer_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(115, 100);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(201, 20);
            this.txtCustomerName.TabIndex = 0;
            // 
            // txtCustomerSurname
            // 
            this.txtCustomerSurname.Location = new System.Drawing.Point(115, 126);
            this.txtCustomerSurname.Name = "txtCustomerSurname";
            this.txtCustomerSurname.Size = new System.Drawing.Size(201, 20);
            this.txtCustomerSurname.TabIndex = 1;
            // 
            // txtIdentityNo
            // 
            this.txtIdentityNo.Location = new System.Drawing.Point(115, 152);
            this.txtIdentityNo.Name = "txtIdentityNo";
            this.txtIdentityNo.Size = new System.Drawing.Size(201, 20);
            this.txtIdentityNo.TabIndex = 2;
            this.txtIdentityNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdentityNo_KeyPress);
            // 
            // txtCustomerId
            // 
            this.txtCustomerId.Location = new System.Drawing.Point(115, 74);
            this.txtCustomerId.Name = "txtCustomerId";
            this.txtCustomerId.ReadOnly = true;
            this.txtCustomerId.Size = new System.Drawing.Size(201, 20);
            this.txtCustomerId.TabIndex = 4;
            // 
            // lblMusteriID
            // 
            this.lblMusteriID.AutoSize = true;
            this.lblMusteriID.ForeColor = System.Drawing.Color.Maroon;
            this.lblMusteriID.Location = new System.Drawing.Point(21, 77);
            this.lblMusteriID.Name = "lblMusteriID";
            this.lblMusteriID.Size = new System.Drawing.Size(88, 13);
            this.lblMusteriID.TabIndex = 5;
            this.lblMusteriID.Text = "Müşteri Numarası";
            // 
            // lblMusteriAdi
            // 
            this.lblMusteriAdi.AutoSize = true;
            this.lblMusteriAdi.ForeColor = System.Drawing.Color.Maroon;
            this.lblMusteriAdi.Location = new System.Drawing.Point(49, 103);
            this.lblMusteriAdi.Name = "lblMusteriAdi";
            this.lblMusteriAdi.Size = new System.Drawing.Size(59, 13);
            this.lblMusteriAdi.TabIndex = 6;
            this.lblMusteriAdi.Text = "Müşteri Adı";
            // 
            // lblMusteriSoyadi
            // 
            this.lblMusteriSoyadi.AutoSize = true;
            this.lblMusteriSoyadi.ForeColor = System.Drawing.Color.Maroon;
            this.lblMusteriSoyadi.Location = new System.Drawing.Point(33, 129);
            this.lblMusteriSoyadi.Name = "lblMusteriSoyadi";
            this.lblMusteriSoyadi.Size = new System.Drawing.Size(76, 13);
            this.lblMusteriSoyadi.TabIndex = 7;
            this.lblMusteriSoyadi.Text = "Müşteri Soyadı";
            // 
            // lblKimlikNo
            // 
            this.lblKimlikNo.AutoSize = true;
            this.lblKimlikNo.ForeColor = System.Drawing.Color.Maroon;
            this.lblKimlikNo.Location = new System.Drawing.Point(58, 155);
            this.lblKimlikNo.Name = "lblKimlikNo";
            this.lblKimlikNo.Size = new System.Drawing.Size(51, 13);
            this.lblKimlikNo.TabIndex = 8;
            this.lblKimlikNo.Text = "Kimlik No";
            // 
            // cmbCustomers
            // 
            this.cmbCustomers.FormattingEnabled = true;
            this.cmbCustomers.Location = new System.Drawing.Point(115, 47);
            this.cmbCustomers.Name = "cmbCustomers";
            this.cmbCustomers.Size = new System.Drawing.Size(201, 21);
            this.cmbCustomers.TabIndex = 13;
            this.cmbCustomers.SelectedIndexChanged += new System.EventHandler(this.cmbCustomers_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(58, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Müşteriler";
            // 
            // MusterilerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(373, 294);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnNewCustomer);
            this.Controls.Add(this.cmbCustomers);
            this.Controls.Add(this.lblMusteriler);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.lblAdres);
            this.Controls.Add(this.lblKimlikNo);
            this.Controls.Add(this.lblMusteriSoyadi);
            this.Controls.Add(this.lblMusteriAdi);
            this.Controls.Add(this.lblMusteriID);
            this.Controls.Add(this.txtCustomerId);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtIdentityNo);
            this.Controls.Add(this.txtCustomerSurname);
            this.Controls.Add(this.txtCustomerName);
            this.Name = "MusterilerForm";
            this.Text = "Musteriler";
            this.Load += new System.EventHandler(this.Musteriler_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblMusteriler;
        private System.Windows.Forms.Button btnNewCustomer;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtCustomerSurname;
        private System.Windows.Forms.TextBox txtIdentityNo;
        private System.Windows.Forms.TextBox txtCustomerId;
        private System.Windows.Forms.Label lblMusteriID;
        private System.Windows.Forms.Label lblMusteriAdi;
        private System.Windows.Forms.Label lblMusteriSoyadi;
        private System.Windows.Forms.Label lblKimlikNo;
        private System.Windows.Forms.ComboBox cmbCustomers;
        private System.Windows.Forms.Label label1;
    }
}