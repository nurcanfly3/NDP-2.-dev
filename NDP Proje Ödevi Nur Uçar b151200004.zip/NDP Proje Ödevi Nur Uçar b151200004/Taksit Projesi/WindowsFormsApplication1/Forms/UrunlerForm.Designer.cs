﻿namespace TaksitApp.Forms
{
    partial class UrunlerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblUrunler = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbProducts = new System.Windows.Forms.ComboBox();
            this.lblFiyat = new System.Windows.Forms.Label();
            this.lblUrunModeli = new System.Windows.Forms.Label();
            this.lblUrunAdi = new System.Windows.Forms.Label();
            this.lblUrunNo = new System.Windows.Forms.Label();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtProductModel = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblRenk = new System.Windows.Forms.Label();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.btnNewProduct = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblUrunler
            // 
            this.lblUrunler.AutoSize = true;
            this.lblUrunler.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblUrunler.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblUrunler.Location = new System.Drawing.Point(144, 9);
            this.lblUrunler.Name = "lblUrunler";
            this.lblUrunler.Size = new System.Drawing.Size(70, 22);
            this.lblUrunler.TabIndex = 13;
            this.lblUrunler.Text = "Ürünler";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(55, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Ürünler";
            // 
            // cmbProducts
            // 
            this.cmbProducts.FormattingEnabled = true;
            this.cmbProducts.Location = new System.Drawing.Point(112, 54);
            this.cmbProducts.Name = "cmbProducts";
            this.cmbProducts.Size = new System.Drawing.Size(201, 21);
            this.cmbProducts.TabIndex = 24;
            this.cmbProducts.SelectedIndexChanged += new System.EventHandler(this.cmbProducts_SelectedIndexChanged);
            // 
            // lblFiyat
            // 
            this.lblFiyat.AutoSize = true;
            this.lblFiyat.ForeColor = System.Drawing.Color.Maroon;
            this.lblFiyat.Location = new System.Drawing.Point(63, 162);
            this.lblFiyat.Name = "lblFiyat";
            this.lblFiyat.Size = new System.Drawing.Size(29, 13);
            this.lblFiyat.TabIndex = 23;
            this.lblFiyat.Text = "Fiyat";
            // 
            // lblUrunModeli
            // 
            this.lblUrunModeli.AutoSize = true;
            this.lblUrunModeli.ForeColor = System.Drawing.Color.Maroon;
            this.lblUrunModeli.Location = new System.Drawing.Point(30, 136);
            this.lblUrunModeli.Name = "lblUrunModeli";
            this.lblUrunModeli.Size = new System.Drawing.Size(64, 13);
            this.lblUrunModeli.TabIndex = 22;
            this.lblUrunModeli.Text = "Ürün Modeli";
            // 
            // lblUrunAdi
            // 
            this.lblUrunAdi.AutoSize = true;
            this.lblUrunAdi.ForeColor = System.Drawing.Color.Maroon;
            this.lblUrunAdi.Location = new System.Drawing.Point(46, 110);
            this.lblUrunAdi.Name = "lblUrunAdi";
            this.lblUrunAdi.Size = new System.Drawing.Size(48, 13);
            this.lblUrunAdi.TabIndex = 21;
            this.lblUrunAdi.Text = "Ürün Adı";
            // 
            // lblUrunNo
            // 
            this.lblUrunNo.AutoSize = true;
            this.lblUrunNo.ForeColor = System.Drawing.Color.Maroon;
            this.lblUrunNo.Location = new System.Drawing.Point(18, 84);
            this.lblUrunNo.Name = "lblUrunNo";
            this.lblUrunNo.Size = new System.Drawing.Size(77, 13);
            this.lblUrunNo.TabIndex = 20;
            this.lblUrunNo.Text = "Ürün Numarası";
            // 
            // txtProductId
            // 
            this.txtProductId.Location = new System.Drawing.Point(112, 81);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.ReadOnly = true;
            this.txtProductId.Size = new System.Drawing.Size(201, 20);
            this.txtProductId.TabIndex = 19;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(112, 159);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(201, 20);
            this.txtPrice.TabIndex = 18;
            // 
            // txtProductModel
            // 
            this.txtProductModel.Location = new System.Drawing.Point(112, 133);
            this.txtProductModel.Name = "txtProductModel";
            this.txtProductModel.Size = new System.Drawing.Size(201, 20);
            this.txtProductModel.TabIndex = 17;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(112, 107);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(201, 20);
            this.txtProductName.TabIndex = 16;
            // 
            // lblRenk
            // 
            this.lblRenk.AutoSize = true;
            this.lblRenk.ForeColor = System.Drawing.Color.Maroon;
            this.lblRenk.Location = new System.Drawing.Point(59, 188);
            this.lblRenk.Name = "lblRenk";
            this.lblRenk.Size = new System.Drawing.Size(33, 13);
            this.lblRenk.TabIndex = 27;
            this.lblRenk.Text = "Renk";
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(112, 185);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(201, 20);
            this.txtColor.TabIndex = 26;
            // 
            // btnNewProduct
            // 
            this.btnNewProduct.ForeColor = System.Drawing.Color.Maroon;
            this.btnNewProduct.Location = new System.Drawing.Point(8, 223);
            this.btnNewProduct.Name = "btnNewProduct";
            this.btnNewProduct.Size = new System.Drawing.Size(118, 23);
            this.btnNewProduct.TabIndex = 30;
            this.btnNewProduct.Text = "Yeni Ürün";
            this.btnNewProduct.UseVisualStyleBackColor = true;
            this.btnNewProduct.Click += new System.EventHandler(this.btnNewProduct_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Maroon;
            this.btnBack.Location = new System.Drawing.Point(250, 223);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(107, 23);
            this.btnBack.TabIndex = 29;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnKaydet
            // 
            this.btnKaydet.ForeColor = System.Drawing.Color.Maroon;
            this.btnKaydet.Location = new System.Drawing.Point(132, 223);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(112, 23);
            this.btnKaydet.TabIndex = 28;
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // UrunlerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(369, 257);
            this.Controls.Add(this.btnNewProduct);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.lblRenk);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbProducts);
            this.Controls.Add(this.lblFiyat);
            this.Controls.Add(this.lblUrunModeli);
            this.Controls.Add(this.lblUrunAdi);
            this.Controls.Add(this.lblUrunNo);
            this.Controls.Add(this.txtProductId);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtProductModel);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.lblUrunler);
            this.Name = "UrunlerForm";
            this.Text = "UrunlerForm";
            this.Load += new System.EventHandler(this.UrunlerForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUrunler;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbProducts;
        private System.Windows.Forms.Label lblFiyat;
        private System.Windows.Forms.Label lblUrunModeli;
        private System.Windows.Forms.Label lblUrunAdi;
        private System.Windows.Forms.Label lblUrunNo;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtProductModel;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblRenk;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.Button btnNewProduct;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnKaydet;
    }
}