﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Model;

namespace TaksitApp.Forms
{
    public partial class YoneticiForm : Form
    {
        User user;
        public YoneticiForm(User user)
        {
            InitializeComponent();
            this.user = user;

            //Yönetici user bilgisi, login olunan kullanıcı üzerinden alınıp constructor'da set ediliyor
            lblAdmin.Text = "Merhaba " + user.Name + " " + user.Surname;
        }

        private void btnSifreDegistir_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Şifre değiştirme ekranını, şifresi değişecek user bilgisiyle çağırma
            ResetPasswordForm r = new ResetPasswordForm(user);
            r.ShowDialog();
            r = null;
            this.Show();
        }

        private void btnMusteriBazli_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Müşteri bazlı tahsilat ekranını çağırma
            MusteriTahsilatGoruntuleForm r = new MusteriTahsilatGoruntuleForm();
            r.ShowDialog();
            r = null;
            this.Show();
        }

        private void btnKullaniciBazli_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Kullanıcı bazlı tahsilat ekranını çağırma
            KullaniciTahsilatGoruntuleForm k = new KullaniciTahsilatGoruntuleForm();
            k.ShowDialog();
            k = null;
            this.Show();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnVadesiGecen_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Vadesi geçen tahsilat ekranını çağırma
            VadesiGecenTahsilatForm v = new VadesiGecenTahsilatForm();
            v.ShowDialog();
            v = null;
            this.Show();
        }

        private void btnSatisciEkle_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Yeni user eklemek için ekranı çağırma
            KullaniciEkleForm k = new KullaniciEkleForm();
            k.ShowDialog();
            k = null;
            this.Show();
        }

        private void btnKilitlenen_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Kilitlenen ekran formunu çağırma
            KilitliHesaplarForm k = new KilitliHesaplarForm();
            k.ShowDialog();
            k = null;
            this.Show();
        }

        private void YoneticiForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
