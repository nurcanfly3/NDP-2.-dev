﻿namespace TaksitApp.Forms
{
    partial class MusteriTahsilatGoruntuleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTahsilat = new System.Windows.Forms.Label();
            this.rbOdenmeyen = new System.Windows.Forms.RadioButton();
            this.rbOdenen = new System.Windows.Forms.RadioButton();
            this.gvGoruntule = new System.Windows.Forms.DataGridView();
            this.cmbMusteri = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvGoruntule)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTahsilat
            // 
            this.lblTahsilat.AutoSize = true;
            this.lblTahsilat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTahsilat.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblTahsilat.Location = new System.Drawing.Point(59, 9);
            this.lblTahsilat.Name = "lblTahsilat";
            this.lblTahsilat.Size = new System.Drawing.Size(300, 22);
            this.lblTahsilat.TabIndex = 17;
            this.lblTahsilat.Text = "Müşteri Bazlı Tahsilat Görüntüleme";
            // 
            // rbOdenmeyen
            // 
            this.rbOdenmeyen.AutoSize = true;
            this.rbOdenmeyen.Checked = true;
            this.rbOdenmeyen.Location = new System.Drawing.Point(63, 46);
            this.rbOdenmeyen.Name = "rbOdenmeyen";
            this.rbOdenmeyen.Size = new System.Drawing.Size(115, 17);
            this.rbOdenmeyen.TabIndex = 18;
            this.rbOdenmeyen.TabStop = true;
            this.rbOdenmeyen.Text = "Tahsil Edilmeyenler";
            this.rbOdenmeyen.UseVisualStyleBackColor = true;
            this.rbOdenmeyen.CheckedChanged += new System.EventHandler(this.rbOdenmeyen_CheckedChanged);
            // 
            // rbOdenen
            // 
            this.rbOdenen.AutoSize = true;
            this.rbOdenen.Location = new System.Drawing.Point(263, 46);
            this.rbOdenen.Name = "rbOdenen";
            this.rbOdenen.Size = new System.Drawing.Size(96, 17);
            this.rbOdenen.TabIndex = 19;
            this.rbOdenen.Text = "Tahsil Edilenler";
            this.rbOdenen.UseVisualStyleBackColor = true;
            this.rbOdenen.CheckedChanged += new System.EventHandler(this.rbOdenen_CheckedChanged);
            // 
            // gvGoruntule
            // 
            this.gvGoruntule.AllowUserToAddRows = false;
            this.gvGoruntule.AllowUserToDeleteRows = false;
            this.gvGoruntule.AllowUserToOrderColumns = true;
            this.gvGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvGoruntule.Location = new System.Drawing.Point(39, 119);
            this.gvGoruntule.Name = "gvGoruntule";
            this.gvGoruntule.ReadOnly = true;
            this.gvGoruntule.Size = new System.Drawing.Size(348, 160);
            this.gvGoruntule.TabIndex = 21;
            // 
            // cmbMusteri
            // 
            this.cmbMusteri.FormattingEnabled = true;
            this.cmbMusteri.Location = new System.Drawing.Point(125, 79);
            this.cmbMusteri.Name = "cmbMusteri";
            this.cmbMusteri.Size = new System.Drawing.Size(198, 21);
            this.cmbMusteri.TabIndex = 22;
            this.cmbMusteri.SelectedIndexChanged += new System.EventHandler(this.cmbMusteri_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(78, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Müşteri";
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBack.Location = new System.Drawing.Point(108, 285);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(215, 23);
            this.btnBack.TabIndex = 24;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // MusteriTahsilatGoruntuleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(430, 320);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbMusteri);
            this.Controls.Add(this.gvGoruntule);
            this.Controls.Add(this.rbOdenen);
            this.Controls.Add(this.rbOdenmeyen);
            this.Controls.Add(this.lblTahsilat);
            this.Name = "MusteriTahsilatGoruntuleForm";
            this.Text = "MusteriTahsilatGoruntuleForm";
            ((System.ComponentModel.ISupportInitialize)(this.gvGoruntule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTahsilat;
        private System.Windows.Forms.RadioButton rbOdenmeyen;
        private System.Windows.Forms.RadioButton rbOdenen;
        private System.Windows.Forms.DataGridView gvGoruntule;
        private System.Windows.Forms.ComboBox cmbMusteri;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBack;
    }
}