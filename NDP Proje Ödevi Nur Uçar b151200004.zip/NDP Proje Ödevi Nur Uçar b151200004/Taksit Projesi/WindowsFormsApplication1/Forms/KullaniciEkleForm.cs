﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;
using TaksitApp.Model;

namespace TaksitApp.Forms
{
    public partial class KullaniciEkleForm : Form
    {
        AdminController ac = new AdminController();
        public KullaniciEkleForm()
        {
            InitializeComponent();
        }

        //Boş text alanlarının kontrolü
        private void btnKaydet_Click(object sender, EventArgs e)
        {
            if (txtKullaniciAdi.Text == "")
            {
                MessageBox.Show("Kullanıcı adı boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtKullaniciAdi.Focus();
                return;
            }

            if (txtAd.Text == "")
            {
                MessageBox.Show("Ad alanı boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAd.Focus();
                return;
            }

            if (txtSoyad.Text == "")
            {
                MessageBox.Show("Soyad alanı boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoyad.Focus();
                return;
            }

            if (txtSifre.Text == "")
            {
                MessageBox.Show("Geçici şifre boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSifre.Focus();
                return;
            }

            if (ac.isUserExists(txtKullaniciAdi.Text))
            {
                MessageBox.Show("Bu kullanıcı acı mevcuttur, lütfen farklı bir kullanıcı adı seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtKullaniciAdi.Clear();
                txtKullaniciAdi.Focus();
                return;
            }

            //Kaydedilecek user'ı obje olarak oluşturup controller'a göndererek veritabanına kaydediyoruz
            User user = new User(txtKullaniciAdi.Text, txtSifre.Text, txtAd.Text, txtSoyad.Text, "S", 0, 1, 0);

            if (ac.insertUser(user))
            {
                MessageBox.Show("Kullanıcı oluşturuldu", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
            } else
            {
                MessageBox.Show("Kullanıcı oluşturulamadı, lütfen destek alınız", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
