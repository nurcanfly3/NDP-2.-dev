﻿namespace TaksitApp
{
    partial class YeniSatisForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmbMusteri = new System.Windows.Forms.ComboBox();
            this.lblMusteri = new System.Windows.Forms.Label();
            this.cmbKart = new System.Windows.Forms.ComboBox();
            this.lblKrediKart = new System.Windows.Forms.Label();
            this.cmbTaksit = new System.Windows.Forms.ComboBox();
            this.lblTaksitSayisi = new System.Windows.Forms.Label();
            this.cmbUrun = new System.Windows.Forms.ComboBox();
            this.lblUrun = new System.Windows.Forms.Label();
            this.dtVadeTarihi = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPesinat = new System.Windows.Forms.Button();
            this.lblTutar = new System.Windows.Forms.Label();
            this.txtTutar = new System.Windows.Forms.TextBox();
            this.lblPesinat = new System.Windows.Forms.Label();
            this.txtPesinat = new System.Windows.Forms.TextBox();
            this.lblFaiz = new System.Windows.Forms.Label();
            this.txtFaiz = new System.Windows.Forms.TextBox();
            this.lblVadeTarihi = new System.Windows.Forms.Label();
            this.taksitDBDataSet = new TaksitApp.TaksitDBDataSet();
            this.taksitDBDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvSatis = new System.Windows.Forms.DataGridView();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblUrunler = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taksitDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taksitDBDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvSatis)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbMusteri
            // 
            this.cmbMusteri.FormattingEnabled = true;
            this.cmbMusteri.Location = new System.Drawing.Point(120, 8);
            this.cmbMusteri.Name = "cmbMusteri";
            this.cmbMusteri.Size = new System.Drawing.Size(215, 21);
            this.cmbMusteri.TabIndex = 0;
            // 
            // lblMusteri
            // 
            this.lblMusteri.AutoSize = true;
            this.lblMusteri.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMusteri.Location = new System.Drawing.Point(73, 11);
            this.lblMusteri.Name = "lblMusteri";
            this.lblMusteri.Size = new System.Drawing.Size(41, 13);
            this.lblMusteri.TabIndex = 1;
            this.lblMusteri.Text = "Müşteri";
            // 
            // cmbKart
            // 
            this.cmbKart.FormattingEnabled = true;
            this.cmbKart.Location = new System.Drawing.Point(120, 62);
            this.cmbKart.Name = "cmbKart";
            this.cmbKart.Size = new System.Drawing.Size(215, 21);
            this.cmbKart.TabIndex = 3;
            this.cmbKart.SelectedIndexChanged += new System.EventHandler(this.cmbKart_SelectedIndexChanged);
            // 
            // lblKrediKart
            // 
            this.lblKrediKart.AutoSize = true;
            this.lblKrediKart.ForeColor = System.Drawing.Color.DarkRed;
            this.lblKrediKart.Location = new System.Drawing.Point(59, 65);
            this.lblKrediKart.Name = "lblKrediKart";
            this.lblKrediKart.Size = new System.Drawing.Size(55, 13);
            this.lblKrediKart.TabIndex = 4;
            this.lblKrediKart.Text = "Kredi Kartı";
            // 
            // cmbTaksit
            // 
            this.cmbTaksit.FormattingEnabled = true;
            this.cmbTaksit.Location = new System.Drawing.Point(120, 90);
            this.cmbTaksit.Name = "cmbTaksit";
            this.cmbTaksit.Size = new System.Drawing.Size(52, 21);
            this.cmbTaksit.TabIndex = 5;
            this.cmbTaksit.SelectedIndexChanged += new System.EventHandler(this.cmbTaksit_SelectedIndexChanged);
            // 
            // lblTaksitSayisi
            // 
            this.lblTaksitSayisi.AutoSize = true;
            this.lblTaksitSayisi.ForeColor = System.Drawing.Color.DarkRed;
            this.lblTaksitSayisi.Location = new System.Drawing.Point(48, 93);
            this.lblTaksitSayisi.Name = "lblTaksitSayisi";
            this.lblTaksitSayisi.Size = new System.Drawing.Size(66, 13);
            this.lblTaksitSayisi.TabIndex = 6;
            this.lblTaksitSayisi.Text = "Taksit Sayısı";
            // 
            // cmbUrun
            // 
            this.cmbUrun.FormattingEnabled = true;
            this.cmbUrun.Location = new System.Drawing.Point(120, 35);
            this.cmbUrun.Name = "cmbUrun";
            this.cmbUrun.Size = new System.Drawing.Size(215, 21);
            this.cmbUrun.TabIndex = 7;
            this.cmbUrun.SelectedIndexChanged += new System.EventHandler(this.cmbUrun_SelectedIndexChanged);
            // 
            // lblUrun
            // 
            this.lblUrun.AutoSize = true;
            this.lblUrun.ForeColor = System.Drawing.Color.DarkRed;
            this.lblUrun.Location = new System.Drawing.Point(84, 38);
            this.lblUrun.Name = "lblUrun";
            this.lblUrun.Size = new System.Drawing.Size(30, 13);
            this.lblUrun.TabIndex = 8;
            this.lblUrun.Text = "Ürün";
            // 
            // dtVadeTarihi
            // 
            this.dtVadeTarihi.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.dtVadeTarihi.Location = new System.Drawing.Point(120, 171);
            this.dtVadeTarihi.Name = "dtVadeTarihi";
            this.dtVadeTarihi.Size = new System.Drawing.Size(200, 20);
            this.dtVadeTarihi.TabIndex = 9;
            this.dtVadeTarihi.Value = new System.DateTime(2020, 5, 2, 0, 0, 0, 0);
            this.dtVadeTarihi.ValueChanged += new System.EventHandler(this.dtVadeTarihi_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Vade Başlangıç Tarihi";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnPesinat);
            this.panel1.Controls.Add(this.lblTutar);
            this.panel1.Controls.Add(this.txtTutar);
            this.panel1.Controls.Add(this.lblPesinat);
            this.panel1.Controls.Add(this.txtPesinat);
            this.panel1.Controls.Add(this.lblFaiz);
            this.panel1.Controls.Add(this.txtFaiz);
            this.panel1.Controls.Add(this.lblVadeTarihi);
            this.panel1.Controls.Add(this.dtVadeTarihi);
            this.panel1.Controls.Add(this.lblUrun);
            this.panel1.Controls.Add(this.cmbUrun);
            this.panel1.Controls.Add(this.lblTaksitSayisi);
            this.panel1.Controls.Add(this.cmbTaksit);
            this.panel1.Controls.Add(this.lblKrediKart);
            this.panel1.Controls.Add(this.cmbKart);
            this.panel1.Controls.Add(this.lblMusteri);
            this.panel1.Controls.Add(this.cmbMusteri);
            this.panel1.ForeColor = System.Drawing.Color.DarkRed;
            this.panel1.Location = new System.Drawing.Point(9, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(349, 205);
            this.panel1.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(305, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "%";
            // 
            // btnPesinat
            // 
            this.btnPesinat.Location = new System.Drawing.Point(226, 144);
            this.btnPesinat.Name = "btnPesinat";
            this.btnPesinat.Size = new System.Drawing.Size(107, 20);
            this.btnPesinat.TabIndex = 17;
            this.btnPesinat.Text = "Peşinat Ödendi";
            this.btnPesinat.UseVisualStyleBackColor = true;
            this.btnPesinat.Click += new System.EventHandler(this.btnPesinat_Click);
            // 
            // lblTutar
            // 
            this.lblTutar.AutoSize = true;
            this.lblTutar.Location = new System.Drawing.Point(81, 121);
            this.lblTutar.Name = "lblTutar";
            this.lblTutar.Size = new System.Drawing.Size(32, 13);
            this.lblTutar.TabIndex = 16;
            this.lblTutar.Text = "Tutar";
            // 
            // txtTutar
            // 
            this.txtTutar.Location = new System.Drawing.Point(120, 118);
            this.txtTutar.Name = "txtTutar";
            this.txtTutar.ReadOnly = true;
            this.txtTutar.Size = new System.Drawing.Size(213, 20);
            this.txtTutar.TabIndex = 15;
            // 
            // lblPesinat
            // 
            this.lblPesinat.AutoSize = true;
            this.lblPesinat.Location = new System.Drawing.Point(73, 147);
            this.lblPesinat.Name = "lblPesinat";
            this.lblPesinat.Size = new System.Drawing.Size(42, 13);
            this.lblPesinat.TabIndex = 14;
            this.lblPesinat.Text = "Peşinat";
            // 
            // txtPesinat
            // 
            this.txtPesinat.Location = new System.Drawing.Point(120, 144);
            this.txtPesinat.Name = "txtPesinat";
            this.txtPesinat.Size = new System.Drawing.Size(100, 20);
            this.txtPesinat.TabIndex = 13;
            this.txtPesinat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPesinat_KeyPress);
            // 
            // lblFaiz
            // 
            this.lblFaiz.AutoSize = true;
            this.lblFaiz.ForeColor = System.Drawing.Color.DarkRed;
            this.lblFaiz.Location = new System.Drawing.Point(200, 93);
            this.lblFaiz.Name = "lblFaiz";
            this.lblFaiz.Size = new System.Drawing.Size(54, 13);
            this.lblFaiz.TabIndex = 12;
            this.lblFaiz.Text = "Faiz Oranı";
            // 
            // txtFaiz
            // 
            this.txtFaiz.Location = new System.Drawing.Point(260, 89);
            this.txtFaiz.Name = "txtFaiz";
            this.txtFaiz.ReadOnly = true;
            this.txtFaiz.Size = new System.Drawing.Size(44, 20);
            this.txtFaiz.TabIndex = 11;
            // 
            // lblVadeTarihi
            // 
            this.lblVadeTarihi.AutoSize = true;
            this.lblVadeTarihi.ForeColor = System.Drawing.Color.DarkRed;
            this.lblVadeTarihi.Location = new System.Drawing.Point(4, 175);
            this.lblVadeTarihi.Name = "lblVadeTarihi";
            this.lblVadeTarihi.Size = new System.Drawing.Size(110, 13);
            this.lblVadeTarihi.TabIndex = 10;
            this.lblVadeTarihi.Text = "Vade Başlangıç Tarihi";
            // 
            // taksitDBDataSet
            // 
            this.taksitDBDataSet.DataSetName = "TaksitDBDataSet";
            this.taksitDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taksitDBDataSetBindingSource
            // 
            this.taksitDBDataSetBindingSource.DataSource = this.taksitDBDataSet;
            this.taksitDBDataSetBindingSource.Position = 0;
            // 
            // gvSatis
            // 
            this.gvSatis.AllowUserToAddRows = false;
            this.gvSatis.AllowUserToDeleteRows = false;
            this.gvSatis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvSatis.Location = new System.Drawing.Point(14, 250);
            this.gvSatis.Name = "gvSatis";
            this.gvSatis.ReadOnly = true;
            this.gvSatis.Size = new System.Drawing.Size(345, 138);
            this.gvSatis.TabIndex = 12;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSave.ForeColor = System.Drawing.Color.Red;
            this.btnSave.Location = new System.Drawing.Point(48, 397);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(134, 23);
            this.btnSave.TabIndex = 13;
            this.btnSave.Text = "Satışı Kaydet";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBack.Location = new System.Drawing.Point(196, 397);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(134, 23);
            this.btnBack.TabIndex = 14;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblUrunler
            // 
            this.lblUrunler.AutoSize = true;
            this.lblUrunler.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblUrunler.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblUrunler.Location = new System.Drawing.Point(136, 9);
            this.lblUrunler.Name = "lblUrunler";
            this.lblUrunler.Size = new System.Drawing.Size(94, 22);
            this.lblUrunler.TabIndex = 15;
            this.lblUrunler.Text = "Yeni Satış";
            // 
            // YeniSatisForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(370, 432);
            this.Controls.Add(this.lblUrunler);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gvSatis);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Name = "YeniSatisForm";
            this.Text = "YeniSatis";
            this.Load += new System.EventHandler(this.YeniSatis_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.taksitDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taksitDBDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvSatis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbMusteri;
        private System.Windows.Forms.Label lblMusteri;
        private System.Windows.Forms.ComboBox cmbKart;
        private System.Windows.Forms.Label lblKrediKart;
        private System.Windows.Forms.ComboBox cmbTaksit;
        private System.Windows.Forms.Label lblTaksitSayisi;
        private System.Windows.Forms.ComboBox cmbUrun;
        private System.Windows.Forms.Label lblUrun;
        private System.Windows.Forms.DateTimePicker dtVadeTarihi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblVadeTarihi;
        private System.Windows.Forms.Label lblFaiz;
        private System.Windows.Forms.TextBox txtFaiz;
        private TaksitDBDataSet taksitDBDataSet;
        private System.Windows.Forms.BindingSource taksitDBDataSetBindingSource;
        private System.Windows.Forms.DataGridView gvSatis;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblUrunler;
        private System.Windows.Forms.Label lblPesinat;
        private System.Windows.Forms.TextBox txtPesinat;
        private System.Windows.Forms.Label lblTutar;
        private System.Windows.Forms.TextBox txtTutar;
        private System.Windows.Forms.Button btnPesinat;
        private System.Windows.Forms.Label label1;
    }
}