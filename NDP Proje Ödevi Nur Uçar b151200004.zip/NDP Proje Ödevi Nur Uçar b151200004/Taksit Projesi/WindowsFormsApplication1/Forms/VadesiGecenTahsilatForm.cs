﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;

namespace TaksitApp.Forms
{
    public partial class VadesiGecenTahsilatForm : Form
    {
        AdminController ac = new AdminController();

        public VadesiGecenTahsilatForm()
        {
            InitializeComponent();
            refreshGridView();
        }

        //Grid view'ı dolduran metod
        private void refreshGridView()
        {
            //Controller aracılığıyla vadesi geçmiş tahsilatlar çağırılarak data table dolduruluyor
            DataTable dt = ac.getAllExpiredPayments();
            if (dt == null)
            {
                gvVadesiGecenler = null;
                return;
            }

            //Buna göre de gridview oluşturuluyor
            gvVadesiGecenler.DataSource = dt;
            dt.Columns[3].ColumnName = "Müşteri Adı";
            dt.Columns[4].ColumnName = "Müşteri Soyadı";
            dt.Columns[5].ColumnName = "Kullanıcı Adı";
            dt.Columns[6].ColumnName = "Kulanıcı Soyadı";
            dt.Columns[7].ColumnName = "Ürün Adı";
            dt.Columns[8].ColumnName = "Ürün Modeli";
            dt.Columns[9].ColumnName = "Kredi Kartı";
            dt.Columns[10].ColumnName = "Aylık Faiz Oranı(%)";
            dt.Columns[11].ColumnName = "Vade Tarihi";
            dt.Columns[12].ColumnName = "Taksit No";
            dt.Columns[13].ColumnName = "Tutar";

            gvVadesiGecenler.Columns[0].Visible = false;
            gvVadesiGecenler.Columns[1].Visible = false;
            gvVadesiGecenler.Columns[2].Visible = false;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
