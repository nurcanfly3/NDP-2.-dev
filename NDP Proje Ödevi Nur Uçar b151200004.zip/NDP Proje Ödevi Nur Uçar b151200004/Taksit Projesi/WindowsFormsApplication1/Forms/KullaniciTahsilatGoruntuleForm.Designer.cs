﻿namespace TaksitApp.Forms
{
    partial class KullaniciTahsilatGoruntuleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBack = new System.Windows.Forms.Button();
            this.lblKullanici = new System.Windows.Forms.Label();
            this.cmbKullanici = new System.Windows.Forms.ComboBox();
            this.gvGoruntule = new System.Windows.Forms.DataGridView();
            this.rbOdenen = new System.Windows.Forms.RadioButton();
            this.rbOdenmeyen = new System.Windows.Forms.RadioButton();
            this.lblTahsilat = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gvGoruntule)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBack.Location = new System.Drawing.Point(111, 281);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(215, 23);
            this.btnBack.TabIndex = 31;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // lblKullanici
            // 
            this.lblKullanici.AutoSize = true;
            this.lblKullanici.ForeColor = System.Drawing.Color.Black;
            this.lblKullanici.Location = new System.Drawing.Point(81, 78);
            this.lblKullanici.Name = "lblKullanici";
            this.lblKullanici.Size = new System.Drawing.Size(46, 13);
            this.lblKullanici.TabIndex = 30;
            this.lblKullanici.Text = "Kullanıcı";
            // 
            // cmbKullanici
            // 
            this.cmbKullanici.FormattingEnabled = true;
            this.cmbKullanici.Location = new System.Drawing.Point(128, 75);
            this.cmbKullanici.Name = "cmbKullanici";
            this.cmbKullanici.Size = new System.Drawing.Size(198, 21);
            this.cmbKullanici.TabIndex = 29;
            this.cmbKullanici.SelectedIndexChanged += new System.EventHandler(this.cmbKullanici_SelectedIndexChanged);
            // 
            // gvGoruntule
            // 
            this.gvGoruntule.AllowUserToAddRows = false;
            this.gvGoruntule.AllowUserToDeleteRows = false;
            this.gvGoruntule.AllowUserToOrderColumns = true;
            this.gvGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvGoruntule.Location = new System.Drawing.Point(42, 115);
            this.gvGoruntule.Name = "gvGoruntule";
            this.gvGoruntule.ReadOnly = true;
            this.gvGoruntule.Size = new System.Drawing.Size(348, 160);
            this.gvGoruntule.TabIndex = 28;
            // 
            // rbOdenen
            // 
            this.rbOdenen.AutoSize = true;
            this.rbOdenen.Location = new System.Drawing.Point(266, 42);
            this.rbOdenen.Name = "rbOdenen";
            this.rbOdenen.Size = new System.Drawing.Size(96, 17);
            this.rbOdenen.TabIndex = 27;
            this.rbOdenen.Text = "Tahsil Edilenler";
            this.rbOdenen.UseVisualStyleBackColor = true;
            this.rbOdenen.CheckedChanged += new System.EventHandler(this.rbOdenen_CheckedChanged);
            // 
            // rbOdenmeyen
            // 
            this.rbOdenmeyen.AutoSize = true;
            this.rbOdenmeyen.Checked = true;
            this.rbOdenmeyen.Location = new System.Drawing.Point(66, 42);
            this.rbOdenmeyen.Name = "rbOdenmeyen";
            this.rbOdenmeyen.Size = new System.Drawing.Size(115, 17);
            this.rbOdenmeyen.TabIndex = 26;
            this.rbOdenmeyen.TabStop = true;
            this.rbOdenmeyen.Text = "Tahsil Edilmeyenler";
            this.rbOdenmeyen.UseVisualStyleBackColor = true;
            this.rbOdenmeyen.CheckedChanged += new System.EventHandler(this.rbOdenmeyen_CheckedChanged);
            // 
            // lblTahsilat
            // 
            this.lblTahsilat.AutoSize = true;
            this.lblTahsilat.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTahsilat.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblTahsilat.Location = new System.Drawing.Point(62, 5);
            this.lblTahsilat.Name = "lblTahsilat";
            this.lblTahsilat.Size = new System.Drawing.Size(312, 22);
            this.lblTahsilat.TabIndex = 25;
            this.lblTahsilat.Text = "Kullanıcı Bazlı Tahsilat Görüntüleme";
            // 
            // KullaniciTahsilatGoruntuleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(437, 316);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.lblKullanici);
            this.Controls.Add(this.cmbKullanici);
            this.Controls.Add(this.gvGoruntule);
            this.Controls.Add(this.rbOdenen);
            this.Controls.Add(this.rbOdenmeyen);
            this.Controls.Add(this.lblTahsilat);
            this.Name = "KullaniciTahsilatGoruntuleForm";
            this.Text = "KullaniciTahsilatGoruntuleForm";
            ((System.ComponentModel.ISupportInitialize)(this.gvGoruntule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblKullanici;
        private System.Windows.Forms.ComboBox cmbKullanici;
        private System.Windows.Forms.DataGridView gvGoruntule;
        private System.Windows.Forms.RadioButton rbOdenen;
        private System.Windows.Forms.RadioButton rbOdenmeyen;
        private System.Windows.Forms.Label lblTahsilat;
    }
}