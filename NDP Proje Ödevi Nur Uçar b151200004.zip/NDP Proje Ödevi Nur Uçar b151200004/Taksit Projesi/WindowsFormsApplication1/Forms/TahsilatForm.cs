﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Model;
using TaksitApp.Controller;

namespace TaksitApp.Forms
{
    public partial class TahsilatForm : Form
    {
        Customer[] customers;
        PaymentController pc = new PaymentController();
        int userId;

        public TahsilatForm(int userId,  Customer[] customers)
        {
            this.customers = customers;
            this.userId = userId;
            InitializeComponent();
            //Müşteri combobox'ı dolduruluyor:
            BindingSource theBindingSource = new BindingSource();
            theBindingSource.DataSource = customers;
            cmbMusteri.DataSource = theBindingSource.DataSource;
            cmbMusteri.DisplayMember = "FullName";
            cmbMusteri.ValueMember = "Id";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnTahsil_Click(object sender, EventArgs e)
        {
            //Grid view de kayıt yoksa kaydedilecek bir satış yoktur, uyarı veriliyor
            if (gvOdenmeyenler.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen tahsil edilecek bir kayıt seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //Gridview de seçilen her kayıt için tahsilat yapılacak, o yüzden seçilen tüm satırları almak için döngü kuruluyor
            foreach (DataGridViewRow row in gvOdenmeyenler.SelectedRows)
            {
            DialogResult dialogResult = MessageBox.Show(gvOdenmeyenler.SelectedRows.Count.ToString()+" adet ödeme tahsil edilecektir, devam edilsin mi?", "Tahsilat", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                        //eğer onay verilirse controller aracılığıyla tahsilat veritabanına kaydediliyor
                        //bunun için hangi satışın tahsil edeceği bilgisi (salesId) bilgisi gönderiliyor
                        int salesId = int.Parse(row.Cells[0].Value.ToString());
                        pc.tahsilEt(salesId);

                } else
                {
                    return;
                }
                //grid güncelleniyor:
                refreshGridView();
            }


        }

        private void cmbMusteri_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Seçilen müşteri bilgisi değiştirilirse grid güncelleniyor
            refreshGridView();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //Ana menüye dönüş için form gizleniyor
            this.Hide();
        }

        private void refreshGridView()
        {
            //Gridview refresh edilmesi için yazılan metod
            Customer selectedCustomer = (Customer)cmbMusteri.SelectedItem;
            if (selectedCustomer == null)
            {
                //Müşteri seçilmediyse gridview de doldurulacak bir tahsilat yoktur
                return;
            }
            //Burada controller aracılığıyla veritabanından seçilen müşterinin ve login olan user'ın kaydettiği satış bilgileri data table'a atılıyor
            DataTable dt = pc.getUserCustomerUnpaidPayments(userId, selectedCustomer.Id);
            if (dt == null)
            {
                //eğer boş geliyorsa grid boş olacaktır
                gvOdenmeyenler = null;
                return;
            }
            //Doluysa gösterilmesi istenen alanlar gösteriliyor, diğerleri gizleniyor
            gvOdenmeyenler.DataSource = dt;
            dt.Columns[1].ColumnName = "Müşteri Adı";
            dt.Columns[4].ColumnName = "Vade Tarihi";
            dt.Columns[5].ColumnName = "Taksit No";
            dt.Columns[6].ColumnName = "Tutar";
            gvOdenmeyenler.Columns[0].Visible = false;
            gvOdenmeyenler.Columns[2].Visible = false;
            gvOdenmeyenler.Columns[3].Visible = false;
            gvOdenmeyenler.Columns[7].Visible = false;
            foreach (DataGridViewRow row in gvOdenmeyenler.Rows)
            {
                //eğer vade tarihi, bugünden eski olan kayıtlar varsa datagridview'da kırmızıya boyanıyor
                if (DateTime.Parse(row.Cells[4].Value.ToString()).Date <= DateTime.Now.Date)
                    row.DefaultCellStyle.BackColor = Color.Red;
            }
            
                
        }

    }
}
