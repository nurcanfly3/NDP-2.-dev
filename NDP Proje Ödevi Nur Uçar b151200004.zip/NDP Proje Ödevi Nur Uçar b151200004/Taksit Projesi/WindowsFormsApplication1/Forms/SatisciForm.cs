﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Model;
using System.Configuration;
using TaksitApp.Controller;
using TaksitApp.Forms;

namespace TaksitApp
{
    public partial class SatisciForm : Form
    {
        //Satış kullanıcısının ihtiyaç duyacağı tüm nesneler object array altında toplanıyor
        User user;
        Customer[] customers;
        Product[] products;
        CreditCard[] creditCards;
        //Veritabanı üzerinde yapılan veya veri getiren işlemler controller sınıfları üzerinden çağırılıyor:
        CustomerController custController = new CustomerController();
        ProductController prodController = new ProductController();
        CreditCardController ccController = new CreditCardController();

        public SatisciForm(User user)
        {
            InitializeComponent();
            this.user = user;
            //Ekrandaki hoşgeldin yazısı, login olan kullanıcının veritabanından çekilip User objesine
            //atıldıktan sonra, objeden isim ve soyisim çağırılmasıyla yazılıyor
            lblSatisci.Text = "Merhaba " + user.Name + " " + user.Surname;
            // Object arrayler bu metodla dolduruluyor:
            populateObjects();

        }

        private void SatisciForm_Load(object sender, EventArgs e)
        {

        }

        private void btnSifreDegistir_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Şifre resetleme ekranı çağırılıyor, login olunan kullanıcın şifresi değiştirileceği için
            //login olunan user nesnesi contructor'a gönderiliyor
            ResetPasswordForm r = new ResetPasswordForm(user);
            r.ShowDialog();
            r = null;
            this.Show();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void btnMusteriler_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Müşteri tanım ekranı, customer object array'in veritabanından doldurulup constructor'a gönderilmesiyle çağırılıyor
            customers = custController.getAllCustomers();
            MusterilerForm r = new MusterilerForm(customers);
            r.ShowDialog();
            r = null;
            this.Show();
        }

        private void btnUrunler_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Ürün tanım ekranı, product object array'in veritabanından doldurulup constructor'a gönderilmesiyle çağırılıyor
            products = prodController.getAllProducts();
            UrunlerForm u = new UrunlerForm(products);
            u.ShowDialog();
            u = null;
            this.Show();
        }

        private void btnKrediKartlari_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Kredi Kartı tanım ekranı, creditCard object array'in veritabanından doldurulup constructor'a gönderilmesiyle çağırılıyor
            creditCards = ccController.getAllCreditCards();
            KrediKartForm k = new KrediKartForm(creditCards);
            k.ShowDialog();
            k = null;
            this.Show();
        }

        private void btnYeniSatis_Click(object sender, EventArgs e)
        {
            //Yeni satış ekranına girildiğinde, tanım ekranlarında bir değişiklik olması ihtimaline karşı,
            //yani müşteri, ürün ya da kredi kartı bilgilerinde değişiklik olduysa diye, yeniden veritabanından
            //çekilip object arrayler dolduruluyor
            populateObjects();

            //Object arrayler boş ise tanım yapılması için kullanıcı yönlendiriliyor
            //Çünkü tanım yapılmamışsa satış yapılamaz
            if (customers.Length == 0)
            {
                MessageBox.Show("Hiç müşteri tanımlanmamış, lütfen önce müşteri tanımlayın.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (creditCards.Length == 0)
            {
                MessageBox.Show("Hiç kredi kartı tanımlanmamış, lütfen önce kredi kartı tanımlayın.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (products.Length == 0)
            {
                MessageBox.Show("Hiç ürün tanımlanmamış, lütfen önce ürün tanımlayın.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            this.Hide();            
            //Yeni satış ekranına girilirken tüm tanımlar kullanılacağı için constructor'da da tüm object arrayler ve user bilgileri gönderiliyor
            YeniSatisForm y = new YeniSatisForm(user, creditCards, customers, products);
            y.ShowDialog();
            y = null;
            this.Show();
        }

        private void populateObjects()
        {
            //Controller aracılığıyla veritabanından bilgiler çekilip objectler'e dolduruluyor
            customers = custController.getAllCustomers();
            products = prodController.getAllProducts();
            creditCards = ccController.getAllCreditCards();
        }

        private void btnTahsilat_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Tahsilatta müşteri seçimi yapılacağı için, oradaki combo box'u güncel verilerle doldurmak için
            //customers objesi veritabanından çekilip dolduruluyor
            customers = custController.getAllCustomers();

            //Tahsilat yapacak olan kullanıcının sadece kendi satışlarını görebilmesi için
            //tahsilat ekranı çağırılırken construcor'a aynı zamanda login olan kullanıcının ID'si gönderiliyor
            TahsilatForm t = new TahsilatForm(user.Id, customers);
            t.ShowDialog();
            t = null;
            this.Show();
        }

        private void SatisciForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
    }
