﻿namespace TaksitApp
{
    partial class SatisciForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSatisci = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnYeniSatis = new System.Windows.Forms.Button();
            this.btnTahsilat = new System.Windows.Forms.Button();
            this.btnSifreDegistir = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnMusteriler = new System.Windows.Forms.Button();
            this.btnKrediKartlari = new System.Windows.Forms.Button();
            this.btnUrunler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSatisci
            // 
            this.lblSatisci.AutoSize = true;
            this.lblSatisci.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSatisci.Location = new System.Drawing.Point(12, 51);
            this.lblSatisci.Name = "lblSatisci";
            this.lblSatisci.Size = new System.Drawing.Size(51, 14);
            this.lblSatisci.TabIndex = 0;
            this.lblSatisci.Text = "Merhaba";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(123, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "TAKSİTLİ SATIŞ EKRANI";
            // 
            // btnYeniSatis
            // 
            this.btnYeniSatis.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnYeniSatis.ForeColor = System.Drawing.Color.DarkRed;
            this.btnYeniSatis.Location = new System.Drawing.Point(127, 78);
            this.btnYeniSatis.Name = "btnYeniSatis";
            this.btnYeniSatis.Size = new System.Drawing.Size(195, 30);
            this.btnYeniSatis.TabIndex = 2;
            this.btnYeniSatis.Text = "Yeni Satış";
            this.btnYeniSatis.UseVisualStyleBackColor = true;
            this.btnYeniSatis.Click += new System.EventHandler(this.btnYeniSatis_Click);
            // 
            // btnTahsilat
            // 
            this.btnTahsilat.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnTahsilat.ForeColor = System.Drawing.Color.DarkRed;
            this.btnTahsilat.Location = new System.Drawing.Point(127, 113);
            this.btnTahsilat.Name = "btnTahsilat";
            this.btnTahsilat.Size = new System.Drawing.Size(195, 30);
            this.btnTahsilat.TabIndex = 3;
            this.btnTahsilat.Text = "Tahsilat";
            this.btnTahsilat.UseVisualStyleBackColor = true;
            this.btnTahsilat.Click += new System.EventHandler(this.btnTahsilat_Click);
            // 
            // btnSifreDegistir
            // 
            this.btnSifreDegistir.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSifreDegistir.ForeColor = System.Drawing.Color.DarkRed;
            this.btnSifreDegistir.Location = new System.Drawing.Point(127, 257);
            this.btnSifreDegistir.Name = "btnSifreDegistir";
            this.btnSifreDegistir.Size = new System.Drawing.Size(195, 30);
            this.btnSifreDegistir.TabIndex = 4;
            this.btnSifreDegistir.Text = "Şifre Değiştir";
            this.btnSifreDegistir.UseVisualStyleBackColor = true;
            this.btnSifreDegistir.Click += new System.EventHandler(this.btnSifreDegistir_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.ForeColor = System.Drawing.Color.Red;
            this.btnCikis.Location = new System.Drawing.Point(127, 293);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(195, 37);
            this.btnCikis.TabIndex = 5;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnMusteriler
            // 
            this.btnMusteriler.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnMusteriler.ForeColor = System.Drawing.Color.DarkRed;
            this.btnMusteriler.Location = new System.Drawing.Point(127, 149);
            this.btnMusteriler.Name = "btnMusteriler";
            this.btnMusteriler.Size = new System.Drawing.Size(195, 30);
            this.btnMusteriler.TabIndex = 6;
            this.btnMusteriler.Text = "Müşteriler";
            this.btnMusteriler.UseVisualStyleBackColor = true;
            this.btnMusteriler.Click += new System.EventHandler(this.btnMusteriler_Click);
            // 
            // btnKrediKartlari
            // 
            this.btnKrediKartlari.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKrediKartlari.ForeColor = System.Drawing.Color.DarkRed;
            this.btnKrediKartlari.Location = new System.Drawing.Point(127, 221);
            this.btnKrediKartlari.Name = "btnKrediKartlari";
            this.btnKrediKartlari.Size = new System.Drawing.Size(195, 30);
            this.btnKrediKartlari.TabIndex = 7;
            this.btnKrediKartlari.Text = "Kredi Kartları";
            this.btnKrediKartlari.UseVisualStyleBackColor = true;
            this.btnKrediKartlari.Click += new System.EventHandler(this.btnKrediKartlari_Click);
            // 
            // btnUrunler
            // 
            this.btnUrunler.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnUrunler.ForeColor = System.Drawing.Color.DarkRed;
            this.btnUrunler.Location = new System.Drawing.Point(127, 185);
            this.btnUrunler.Name = "btnUrunler";
            this.btnUrunler.Size = new System.Drawing.Size(195, 30);
            this.btnUrunler.TabIndex = 8;
            this.btnUrunler.Text = "Ürünler";
            this.btnUrunler.UseVisualStyleBackColor = true;
            this.btnUrunler.Click += new System.EventHandler(this.btnUrunler_Click);
            // 
            // SatisciForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(453, 340);
            this.Controls.Add(this.btnUrunler);
            this.Controls.Add(this.btnKrediKartlari);
            this.Controls.Add(this.btnMusteriler);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnSifreDegistir);
            this.Controls.Add(this.btnTahsilat);
            this.Controls.Add(this.btnYeniSatis);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSatisci);
            this.Name = "SatisciForm";
            this.Text = "Satışçı Ekranı";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SatisciForm_FormClosing);
            this.Load += new System.EventHandler(this.SatisciForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSatisci;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnYeniSatis;
        private System.Windows.Forms.Button btnTahsilat;
        private System.Windows.Forms.Button btnSifreDegistir;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnMusteriler;
        private System.Windows.Forms.Button btnKrediKartlari;
        private System.Windows.Forms.Button btnUrunler;
    }
}