﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;
using TaksitApp.Model;

namespace TaksitApp.Forms
{
    public partial class KilitliHesaplarForm : Form
    {
        User[] users;
        AdminController ac = new AdminController();

        public KilitliHesaplarForm()
        {
            InitializeComponent();
            //Hangi user'ların kilitli olduğu bilgisi controller aracılığıyla veritabanından çağırılıyor
            users = ac.getLockedUsers();
            BindingSource theBindingSource = new BindingSource();
            //Kilitli userlar combobox üzerinde dolduruluyor
            theBindingSource.DataSource = users;
            cmbLockedUsers.DataSource = theBindingSource.DataSource;
            cmbLockedUsers.DisplayMember = "UserName";
            cmbLockedUsers.ValueMember = "Id";

        }

        private void btnKilidiAc_Click(object sender, EventArgs e)
        {
            //Boş text alanların kontrolü yapılıyor
            if (cmbLockedUsers.SelectedItem == null)
            {
                MessageBox.Show("Lütfen kilit kaldırmak için kullanıcı seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (txtPassword.Text == "")
            {
                MessageBox.Show("Geçici şifre boş olamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtPassword.Focus();
            }

            //Seçilen user'ın kilidi controller aracılığyla veritabanı üzerinde update edilerek kaldırılıyor
            if (ac.releaseUserLock(txtPassword.Text, int.Parse(cmbLockedUsers.SelectedValue.ToString())))
            {
                MessageBox.Show("Kilit kaldırıldı", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
            } else
            {
                MessageBox.Show("Kilit kaldırılamadı, lütfen destek alınız", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
