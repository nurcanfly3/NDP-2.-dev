﻿namespace TaksitApp.Forms
{
    partial class KrediKartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKrediKart = new System.Windows.Forms.Label();
            this.cmbCreditCards = new System.Windows.Forms.ComboBox();
            this.lblMaxTaksit = new System.Windows.Forms.Label();
            this.lblFaiz = new System.Windows.Forms.Label();
            this.lblKartId = new System.Windows.Forms.Label();
            this.txtCreditCardId = new System.Windows.Forms.TextBox();
            this.txtMaxInstallment = new System.Windows.Forms.TextBox();
            this.txtTaxPercentage = new System.Windows.Forms.TextBox();
            this.lblKrediKartlari = new System.Windows.Forms.Label();
            this.lblCardName = new System.Windows.Forms.Label();
            this.txtCardName = new System.Windows.Forms.TextBox();
            this.btnNewCard = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblKrediKart
            // 
            this.lblKrediKart.AutoSize = true;
            this.lblKrediKart.ForeColor = System.Drawing.Color.Maroon;
            this.lblKrediKart.Location = new System.Drawing.Point(33, 62);
            this.lblKrediKart.Name = "lblKrediKart";
            this.lblKrediKart.Size = new System.Drawing.Size(66, 13);
            this.lblKrediKart.TabIndex = 36;
            this.lblKrediKart.Text = "Kredi Kartları";
            // 
            // cmbCreditCards
            // 
            this.cmbCreditCards.FormattingEnabled = true;
            this.cmbCreditCards.Location = new System.Drawing.Point(106, 59);
            this.cmbCreditCards.Name = "cmbCreditCards";
            this.cmbCreditCards.Size = new System.Drawing.Size(201, 21);
            this.cmbCreditCards.TabIndex = 35;
            this.cmbCreditCards.SelectedIndexChanged += new System.EventHandler(this.cmbCreditCards_SelectedIndexChanged);
            // 
            // lblMaxTaksit
            // 
            this.lblMaxTaksit.AutoSize = true;
            this.lblMaxTaksit.ForeColor = System.Drawing.Color.Maroon;
            this.lblMaxTaksit.Location = new System.Drawing.Point(11, 167);
            this.lblMaxTaksit.Name = "lblMaxTaksit";
            this.lblMaxTaksit.Size = new System.Drawing.Size(89, 13);
            this.lblMaxTaksit.TabIndex = 33;
            this.lblMaxTaksit.Text = "Maksimum Taksit";
            // 
            // lblFaiz
            // 
            this.lblFaiz.AutoSize = true;
            this.lblFaiz.ForeColor = System.Drawing.Color.Maroon;
            this.lblFaiz.Location = new System.Drawing.Point(46, 141);
            this.lblFaiz.Name = "lblFaiz";
            this.lblFaiz.Size = new System.Drawing.Size(54, 13);
            this.lblFaiz.TabIndex = 32;
            this.lblFaiz.Text = "Faiz Oranı";
            // 
            // lblKartId
            // 
            this.lblKartId.AutoSize = true;
            this.lblKartId.ForeColor = System.Drawing.Color.Maroon;
            this.lblKartId.Location = new System.Drawing.Point(33, 89);
            this.lblKartId.Name = "lblKartId";
            this.lblKartId.Size = new System.Drawing.Size(67, 13);
            this.lblKartId.TabIndex = 31;
            this.lblKartId.Text = "Kredi Kartı Id";
            // 
            // txtCreditCardId
            // 
            this.txtCreditCardId.Location = new System.Drawing.Point(106, 86);
            this.txtCreditCardId.Name = "txtCreditCardId";
            this.txtCreditCardId.ReadOnly = true;
            this.txtCreditCardId.Size = new System.Drawing.Size(201, 20);
            this.txtCreditCardId.TabIndex = 30;
            // 
            // txtMaxInstallment
            // 
            this.txtMaxInstallment.Location = new System.Drawing.Point(106, 164);
            this.txtMaxInstallment.Name = "txtMaxInstallment";
            this.txtMaxInstallment.Size = new System.Drawing.Size(201, 20);
            this.txtMaxInstallment.TabIndex = 28;
            this.txtMaxInstallment.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMaxInstallment_KeyPress);
            // 
            // txtTaxPercentage
            // 
            this.txtTaxPercentage.Location = new System.Drawing.Point(106, 138);
            this.txtTaxPercentage.Name = "txtTaxPercentage";
            this.txtTaxPercentage.Size = new System.Drawing.Size(201, 20);
            this.txtTaxPercentage.TabIndex = 27;
            this.txtTaxPercentage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTaxPercentage_KeyPress);
            // 
            // lblKrediKartlari
            // 
            this.lblKrediKartlari.AutoSize = true;
            this.lblKrediKartlari.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKrediKartlari.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblKrediKartlari.Location = new System.Drawing.Point(119, 19);
            this.lblKrediKartlari.Name = "lblKrediKartlari";
            this.lblKrediKartlari.Size = new System.Drawing.Size(120, 22);
            this.lblKrediKartlari.TabIndex = 26;
            this.lblKrediKartlari.Text = "Kredi Kartları";
            // 
            // lblCardName
            // 
            this.lblCardName.AutoSize = true;
            this.lblCardName.ForeColor = System.Drawing.Color.Maroon;
            this.lblCardName.Location = new System.Drawing.Point(55, 115);
            this.lblCardName.Name = "lblCardName";
            this.lblCardName.Size = new System.Drawing.Size(44, 13);
            this.lblCardName.TabIndex = 38;
            this.lblCardName.Text = "Kart Adı";
            // 
            // txtCardName
            // 
            this.txtCardName.Location = new System.Drawing.Point(106, 112);
            this.txtCardName.Name = "txtCardName";
            this.txtCardName.Size = new System.Drawing.Size(201, 20);
            this.txtCardName.TabIndex = 37;
            // 
            // btnNewCard
            // 
            this.btnNewCard.ForeColor = System.Drawing.Color.Maroon;
            this.btnNewCard.Location = new System.Drawing.Point(3, 214);
            this.btnNewCard.Name = "btnNewCard";
            this.btnNewCard.Size = new System.Drawing.Size(118, 23);
            this.btnNewCard.TabIndex = 41;
            this.btnNewCard.Text = "Yeni Kart";
            this.btnNewCard.UseVisualStyleBackColor = true;
            this.btnNewCard.Click += new System.EventHandler(this.btnNewCard_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.Maroon;
            this.btnBack.Location = new System.Drawing.Point(245, 214);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(107, 23);
            this.btnBack.TabIndex = 40;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnBack_MouseClick);
            // 
            // btnKaydet
            // 
            this.btnKaydet.ForeColor = System.Drawing.Color.Maroon;
            this.btnKaydet.Location = new System.Drawing.Point(127, 214);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(112, 23);
            this.btnKaydet.TabIndex = 39;
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = true;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // KrediKartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(355, 249);
            this.Controls.Add(this.btnNewCard);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.lblCardName);
            this.Controls.Add(this.txtCardName);
            this.Controls.Add(this.lblKrediKart);
            this.Controls.Add(this.cmbCreditCards);
            this.Controls.Add(this.lblMaxTaksit);
            this.Controls.Add(this.lblFaiz);
            this.Controls.Add(this.lblKartId);
            this.Controls.Add(this.txtCreditCardId);
            this.Controls.Add(this.txtMaxInstallment);
            this.Controls.Add(this.txtTaxPercentage);
            this.Controls.Add(this.lblKrediKartlari);
            this.Name = "KrediKartForm";
            this.Text = "KrediKartForm";
            this.Load += new System.EventHandler(this.KrediKartForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKrediKart;
        private System.Windows.Forms.ComboBox cmbCreditCards;
        private System.Windows.Forms.Label lblMaxTaksit;
        private System.Windows.Forms.Label lblFaiz;
        private System.Windows.Forms.Label lblKartId;
        private System.Windows.Forms.TextBox txtCreditCardId;
        private System.Windows.Forms.TextBox txtMaxInstallment;
        private System.Windows.Forms.TextBox txtTaxPercentage;
        private System.Windows.Forms.Label lblKrediKartlari;
        private System.Windows.Forms.Label lblCardName;
        private System.Windows.Forms.TextBox txtCardName;
        private System.Windows.Forms.Button btnNewCard;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnKaydet;
    }
}