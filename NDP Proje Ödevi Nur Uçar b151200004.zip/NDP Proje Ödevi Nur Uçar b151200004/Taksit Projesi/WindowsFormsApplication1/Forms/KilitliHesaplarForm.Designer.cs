﻿namespace TaksitApp.Forms
{
    partial class KilitliHesaplarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKilitliHesaplar = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnKilidiAc = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.cmbLockedUsers = new System.Windows.Forms.ComboBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblKilitliHesaplar
            // 
            this.lblKilitliHesaplar.AutoSize = true;
            this.lblKilitliHesaplar.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKilitliHesaplar.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.lblKilitliHesaplar.Location = new System.Drawing.Point(58, 9);
            this.lblKilitliHesaplar.Name = "lblKilitliHesaplar";
            this.lblKilitliHesaplar.Size = new System.Drawing.Size(166, 22);
            this.lblKilitliHesaplar.TabIndex = 27;
            this.lblKilitliHesaplar.Text = "Kilitlenen Hesaplar";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(98, 93);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(174, 20);
            this.txtPassword.TabIndex = 29;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(12, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Yeni Geçici Şifre";
            // 
            // btnKilidiAc
            // 
            this.btnKilidiAc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKilidiAc.ForeColor = System.Drawing.Color.Red;
            this.btnKilidiAc.Location = new System.Drawing.Point(12, 136);
            this.btnKilidiAc.Name = "btnKilidiAc";
            this.btnKilidiAc.Size = new System.Drawing.Size(116, 23);
            this.btnKilidiAc.TabIndex = 31;
            this.btnKilidiAc.Text = "Kilidi Kaldır";
            this.btnKilidiAc.UseVisualStyleBackColor = true;
            this.btnKilidiAc.Click += new System.EventHandler(this.btnKilidiAc_Click);
            // 
            // btnBack
            // 
            this.btnBack.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBack.Location = new System.Drawing.Point(156, 136);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(116, 23);
            this.btnBack.TabIndex = 32;
            this.btnBack.Text = "Menüye Dön";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // cmbLockedUsers
            // 
            this.cmbLockedUsers.FormattingEnabled = true;
            this.cmbLockedUsers.Location = new System.Drawing.Point(98, 54);
            this.cmbLockedUsers.Name = "cmbLockedUsers";
            this.cmbLockedUsers.Size = new System.Drawing.Size(174, 21);
            this.cmbLockedUsers.TabIndex = 33;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.ForeColor = System.Drawing.Color.DarkRed;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(28, 57);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(64, 13);
            this.lblKullaniciAdi.TabIndex = 34;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı";
            // 
            // KilitliHesaplarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaShell;
            this.ClientSize = new System.Drawing.Size(284, 173);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.cmbLockedUsers);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnKilidiAc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblKilitliHesaplar);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "KilitliHesaplarForm";
            this.Text = "KilitliHesaplar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKilitliHesaplar;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnKilidiAc;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ComboBox cmbLockedUsers;
        private System.Windows.Forms.Label lblKullaniciAdi;
    }
}