﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;
using TaksitApp.Model;

namespace TaksitApp.Forms
{
    public partial class UrunlerForm : Form
    {

        Product[] products;
        Product selectedProduct;
        ProductController p = new ProductController();


        public UrunlerForm(Product[] products)
        {
            //Products object array contructor'da dolduruluyor
            this.products = products;
            InitializeComponent();
        }

        private void btnNewProduct_Click(object sender, EventArgs e)
        {
            // Yeni ürün girmek için bu bilgileri ve id alanını temizleme işlemi yapılıyor:
            cmbProducts.Hide();
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtProductModel.Text = "";
            txtPrice.Text = "";
            txtColor.Text = "";
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            //integer olması gereken alanlar boş ise 0'a set ediliyor
            double price;
            if (txtPrice.Text != "")
            {
                price =  Double.Parse(txtPrice.Text);
            }
            else price = 0;

            // Id alanı boş olduğu zaman insert çalışacak, boş değilse önceden kaydedilmiş bir ürün seçili demektir
            // Bu durumda ürün bilgileri bir objeye atılıp ilgili veritabanı tablosunda bilgileri güncellenecek
            if (txtProductId.Text == "")
            {
                Product newProduct = new Product(txtProductName.Text, price, txtProductModel.Text, txtColor.Text);
                if (p.insertProduct(newProduct))
                {
                    MessageBox.Show("Yeni Ürün Kaydedildi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Yeni Ürün Kaydedilemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                selectedProduct.Name = txtProductName.Text;
                selectedProduct.Price = price;
                selectedProduct.Model = txtProductModel.Text;
                selectedProduct.Color = txtColor.Text;
                if (p.updateProduct(selectedProduct))
                {
                    MessageBox.Show("Ürün bilgileri güncellendi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Ürün bilgileri güncellenemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void UrunlerForm_Load(object sender, EventArgs e)
        {
            BindingSource theBindingSource = new BindingSource();
            theBindingSource.DataSource = products;
            cmbProducts.DataSource = theBindingSource.DataSource;
            cmbProducts.DisplayMember = "Name";
            cmbProducts.ValueMember = "Id";
        }

        private void cmbProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Combobox dan ürün seçimi değiştiği zaman, ekrandaki alanlara seçilen ürün bilgileri getiriliyor
            Object selectedItem = cmbProducts.SelectedItem;
            Product p = (Product)selectedItem;
            selectedProduct = p;
            txtProductId.Text = p.Id.ToString();
            txtProductName.Text = p.Name;
            txtPrice.Text = p.Price.ToString();
            txtProductModel.Text = p.Model;
            txtColor.Text = p.Color;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
