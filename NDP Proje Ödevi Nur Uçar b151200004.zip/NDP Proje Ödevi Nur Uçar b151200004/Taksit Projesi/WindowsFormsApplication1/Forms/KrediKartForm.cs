﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TaksitApp.Controller;
using TaksitApp.Model;

namespace TaksitApp.Forms
{
    public partial class KrediKartForm : Form
    {
        CreditCard[] creditCards;
        CreditCard selectedCreditCard;
        CreditCardController c = new CreditCardController();

        public KrediKartForm(CreditCard[] creditCards)
        {
            //Constructor'a tüm kredi kartı bilgileri object array halinde getiriliyor
            this.creditCards = creditCards;
            InitializeComponent();
        }

        private void KrediKartForm_Load(object sender, EventArgs e)
        {
            //Gelen kredi kartı obje array'inden combobox dolduruluyor:
            BindingSource theBindingSource = new BindingSource();
            theBindingSource.DataSource = creditCards;
            cmbCreditCards.DataSource = theBindingSource.DataSource;
            cmbCreditCards.DisplayMember = "CardName";
            cmbCreditCards.ValueMember = "Id";
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            //integer olması gereken alanlar boş ise 0'a set ediliyor
            int taxPercentage;
            if (txtTaxPercentage.Text != "")
            {
                taxPercentage = int.Parse(txtTaxPercentage.Text);
            }
            else taxPercentage = 0;

            int maxInstallment;
            if (txtMaxInstallment.Text != "")
            {
                maxInstallment = int.Parse(txtMaxInstallment.Text);
            }
            else maxInstallment = 0;

            // Id alanı boş olduğu zaman insert çalışacak, boş değilse önceden kaydedilmiş bir kredi kartı seçili demektir
            // Bu durumda kart bilgileri bir objeye atılıp ilgili veritabanı tablosunda bilgileri güncellenecek
            if (txtCreditCardId.Text == "")
            {
                CreditCard newCreditCard = new CreditCard(txtCardName.Text, taxPercentage, maxInstallment);
                if (c.insertCreditCard(newCreditCard))
                {
                    MessageBox.Show("Yeni Kredi Kartı Kaydedildi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                }
                //Herhangi bir nedenden dolayı veritabanına kayıt atılamadığında hata veriliyor:
                else
                {
                    MessageBox.Show("Yeni Kredi Kartı Kaydedilemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            else
            {
                selectedCreditCard.CardName = txtCardName.Text;
                selectedCreditCard.TaxPercentage = taxPercentage;
                selectedCreditCard.MaxInstallments = maxInstallment;
                if (c.updateCreditCard(selectedCreditCard))
                {
                    MessageBox.Show("Kredi kartı bilgileri güncellendi", "Bilgilendirme", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                //Herhangi bir nedenden dolayı veritabanına kayıt atılamadığında hata veriliyor:
                {
                    MessageBox.Show("Kredi kartı bilgileri güncellenemedi, lütfen destek isteyiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void cmbCreditCards_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Combobox dan kredi kartı seçimi değiştiği zaman, ekrandaki alanlara seçilen kredi kartı bilgileri getiriliyor
            Object selectedItem = cmbCreditCards.SelectedItem;
            CreditCard cc = (CreditCard)selectedItem;
            selectedCreditCard = cc;
            txtCreditCardId.Text = cc.Id.ToString();
            txtCardName.Text = cc.CardName;
            txtTaxPercentage.Text = cc.TaxPercentage.ToString();
            txtMaxInstallment.Text = cc.MaxInstallments.ToString();

        }


        private void btnNewCard_Click(object sender, EventArgs e)
        {
            
            // Yeni kart girmek için bu bilgileri ve id alanını temizleme işlemi yapılıyor:
            cmbCreditCards.Hide();
            txtCardName.Text = "";
            txtCreditCardId.Text = "";
            txtMaxInstallment.Text = "";
            txtTaxPercentage.Text = "";
        }

        private void txtTaxPercentage_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Yalnızca silme tuşu ve yalnızca rakamlara izin vermek için yazılan kod:
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == 8);
        }

        private void txtMaxInstallment_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Yalnızca silme tuşu ve yalnızca rakamlara izin vermek için yazılan kod:
            e.Handled = !(char.IsDigit(e.KeyChar) || e.KeyChar == 8);
        }

        private void btnBack_MouseClick(object sender, MouseEventArgs e)
        {
            //Menüye dönmek için içinde bulunulan form gizleniyor
            this.Hide();
        }
    }
}
